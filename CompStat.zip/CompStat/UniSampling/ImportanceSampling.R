library('microbenchmark')
library('ggplot2')
library('profvis')
library('Rcpp')
# #muhat
# lambda<-2
# m<-1000
# simX<-rpois(m,lambda)
# muhat<-mean(h(simX,n))
# #sigmahat^2
# sigmahat2<-(1/(m-1))*sum((simX-(mean(h(simX,n)))^2))
# #confidence
# confidence<-c(muhat-1.96*sigmahat2/sqrt(m),muhat+1.96*sigmahat2/sqrt(m))

#Small step towards generality
h<-function(x,n)as.numeric(((x/n-2)/sqrt(2/n)>=1.645))
n<-25
m<-1000
lambda<-seq(1e-10,10,by=1e-2)
lambda<-lambda*n
betaMC<-matrix(NA,nrow = length(lambda),ncol=4)
#Using lambda0=lambda
for (i in (seq_along(lambda))){
  simX<-rpois(m,lambda[i])
  betaMC[i,1]<-mean(h(simX,n))
  #sigmahat^2
  betaMC[i,2]<-(1/(m-1))*sum((h(simX,n)-(betaMC[i,1]))^2)
  #confidence
  tmp<-1.96*betaMC[i,2]/sqrt(m)
  betaMC[i,3]<-betaMC[i,1]-tmp
  betaMC[i,4]<-betaMC[i,1]+tmp
}
lambda<-lambda/n
plot(lambda,betaMC[,1])
 lines(lambda,betaMC[,3])
 lines(lambda,betaMC[,4])

plot(lambda,betaMC[,3]-betaMC[,1],type="l",ylim=c(min(betaMC[,3]-betaMC[,1],betaMC[,4]-betaMC[,1]),max(betaMC[,3]-betaMC[,1],betaMC[,4]-betaMC[,1])))
lines(lambda,betaMC[,4]-betaMC[,1])

#Including weighting function 
# seed<-.Random.seed
# save(seed,file="seed.RData") 
.Random.seed<-seed
n<-25
m<-1000
lambda<-seq(1e-10,10,by=5e-2)
betaMC<-matrix(NA,nrow = length(lambda),ncol=4)
lambda0<-2
lambda<-lambda*n;lambda0<-lambda0*n;
simX<-rpois(m,lambda0)
for (i in (seq_along(lambda))){
  tmp2<-wstar(lambda[i],lambda0,simX)
  betaMC[i,1]<-mean(h(simX,n)*tmp2)
  #sigmahat^2
  betaMC[i,2]<-(1/(m-1))*sum((h(simX,n)*tmp2-(betaMC[i,1]))^2)
  #confidence
  tmp<-1.96*betaMC[i,2]/sqrt(m)
  betaMC[i,3]<-betaMC[i,1]-tmp
  betaMC[i,4]<-betaMC[i,1]+tmp
}
lambda<-lambda/n;lambda0<-lambda0/n;
#plot(lambda,betaMC[,1],ylim=c(min(betaMC[,1],betaMC[,3],betaMC[,4]),max(betaMC[,1],betaMC[,3],betaMC[,4])))
plot(lambda,betaMC[,1])
lines(lambda,betaMC[,3])
lines(lambda,betaMC[,4])

plot(lambda,betaMC[,3]-betaMC[,1],type="l",ylim=c(min(betaMC[,3]-betaMC[,1],betaMC[,4]-betaMC[,1]),max(betaMC[,3]-betaMC[,1],betaMC[,4]-betaMC[,1])))
lines(lambda,betaMC[,4]-betaMC[,1])


plot(seq_along(tmp2),tmp2)


#Including weighting function std weights
#Variance NOT correct yet
n<-25
m<-1000
lambda<-seq(1e-10,10,by=5e-2)
betaMC<-matrix(NA,nrow = length(lambda),ncol=4)
lambda0<-2
lambda<-lambda*n;lambda0<-lambda0*n;
simX<-rpois(m,lambda0)
for (i in (seq_along(lambda))){
  tmp2<-w(lambda[i],lambda0,simX)
  betaMC[i,1]<-sum(h(simX,n)*tmp2)
  #sigmahat^2
  betaMC[i,2]<-(1/(m-1))*sum((h(simX,n)*tmp2-(betaMC[i,1]))^2)
  #confidence
  tmp<-1.96*betaMC[i,2]/sqrt(m)
  betaMC[i,3]<-betaMC[i,1]-tmp
  betaMC[i,4]<-betaMC[i,1]+tmp
}
lambda<-lambda/n;lambda0<-lambda0/n;
#plot(lambda,betaMC[,1],ylim=c(min(betaMC[,1],betaMC[,3],betaMC[,4]),max(betaMC[,1],betaMC[,3],betaMC[,4])))
plot(lambda,betaMC[,1])
lines(lambda,betaMC[,3])
lines(lambda,betaMC[,4])

plot(lambda,betaMC[,3]-betaMC[,1],type="l",ylim=c(min(betaMC[,3]-betaMC[,1],betaMC[,4]-betaMC[,1]),max(betaMC[,3]-betaMC[,1],betaMC[,4]-betaMC[,1])))
lines(lambda,betaMC[,4]-betaMC[,1])


h<-function(x)as.numeric(x>=61.632)
n<-25
m<-1000
lambda<-seq(1e-10,5,by=2e-2)
beta<-matrix(NA,nrow = length(lambda),ncol=4)
lambda0<-3
lambda<-lambda*n;lambda0<-lambda0*n;
simX<-rpois(m,lambda0)
for(i in(seq_along(lambda))){
  #simX<-rpois(m,lambda[i])
  ImpSampObj<-structure(list(x = simX, lambda = lambda[i], lambda0 = lambda0), class = "doublePois")
  beta[i,]<-MeanVarStdW(h, ImpSampObj)
}
lambda<-lambda/n;lambda0<-lambda0/n;
plot(lambda,beta[,1])

h<-function(x)as.numeric(x >= 61.632)
n<-25
m<-1000
lambda<-2
lambda0<-2
method<-"MC"
doublePoisProblem(h, n, m, lambda, lambda0, method)
method<-"StdW"
doublePoisProblem(h, n, m, lambda, lambda0, method)
method<-"SimpleW"
doublePoisProblem(h, n, m, lambda, lambda0, method)


######### Power curve
h<-function(y)as.numeric(y$x >= 61.632)
n<-25
m<-1000
lambda0<-3
lambda <- seq(1e-10, 5, by = 2e-2)


method <- "MC"
impSampObj <- doublePoisProblem(h, n, m, lambda = 2, method = method)
ImpSample(impSampObj)$resultVector
method <- "StdW"
set.seed(123)
impSampObj <- doublePoisProblem(h, n, m, lambda = 2, method = method)
ImpSample(impSampObj)$resultVector
tmp <- microbenchmark(ImpSampleStdWRcpp(impSampObj)$resultVector, times = 20)
method <- "SimpleW"
impSampObj <- doublePoisProblem(h, n, m, lambda = 2, method = method)
ImpSample(impSampObj)$resultVector
method <- "StdWRcpp"
set.seed(123)
impSampObj <- doublePoisProblem(h, n, m, lambda = 2, method = method)
ImpSample(impSampObj)$resultVector
tmp2 <- microbenchmark(ImpSampleStdWRcpp(impSampObj)$resultVector, times = 20)


#MC
method<-"MC"
resultMatrix1 <- matrix(NA, nrow = length(lambda), ncol = 4)
for(i in seq_along(lambda)){
  impSampObj <-  doublePoisProblem(h, n, m, lambda[i], method = method)
  resultMatrix1[i, ] <- ImpSample(impSampObj)$resultVector
}
plot(lambda,resultMatrix1[,1])
lines(lambda,resultMatrix1[,3], lwd=1)
lines(lambda,resultMatrix1[,4], lwd=1)

## Std weights
method <- "StdW"
resultMatrix2 <- matrix(NA, nrow = length(lambda), ncol = 4)
simX<-rpois(m, n*lambda0)
for(i in seq_along(lambda)){
  impSampObj <- doublePoisProblem(h, n, m, lambda[i], lambda0, method, simX)
  resultMatrix2[i, ] <- ImpSample(impSampObj)$resultVector
}
plot(lambda,resultMatrix2[, 1])
lines(lambda,resultMatrix2[, 3])
lines(lambda,resultMatrix2[, 4])

# Simple weights
set.seed(123)
method <- "SimpleW"
resultMatrix3 <- matrix(NA, nrow = length(lambda), ncol = 4)
simX<-rpois(m, n*lambda0)
tmplist <- list()
for(i in seq_along(lambda)){
  impSampObj <- doublePoisProblem(h, n, m, lambda[i], lambda0, method, simX)
  tmp <- ImpSample(impSampObj)
  resultMatrix3[i, ] <- tmp$resultVector
  tmplist[[i]] <- tmp$weights
}

plot(lambda,resultMatrix3[, 1])
plot(lambda,resultMatrix3[, 3]-resultMatrix3[, 1],type = "l", ylim=c(-0.2,0.2))
lines(lambda,resultMatrix3[, 4]-resultMatrix3[, 1])

hist(log(tmplist[[125]]))
max(tmplist[[125]])
hist(log(tmplist[[240]]))
max(tmplist[[240]])

#Variabels to fix:
#n - obv. fixed; m, lambda
#Lambda leave fixed at 2, anything else is looking into the powercurve setup
#m - could look into changing this
#Lambda0 - not leaving this fixed

###Timing different lambda0's - finding best lambda0
h<-function(y$x)as.numeric(x >= 61.632)
n<-25
m<-1000
lambda<-2
lambda0<-2
TmpTimeValues<-microbenchmark(doublePoisProblem(h, n, m, lambda, lambda0, "MC"), unit = "us", times = 100L)
TimeValues<-summary(TmpTimeValues)[,c(1,4,5)]

lambda0<-seq(2,5,length.out = 100)
### Takes long time, but works fine
# for( i in (seq_along(lambda0))){
#   TmpTimeValues<-microbenchmark(doublePoisProblem(h, n, m, lambda, lambda0[i], "StdW"), times = 100L)
#   TimeValues<-rbind(TimeValues,summary(TmpTimeValues)[,c(1,4,5)])
# }

#INTERESTING doublePoisProblem(h, n, m, lambda, lambda0[i], "StdW") can have small negative variance - rounded to nearest 1e-10
StdWTestValues<-matrix(data = NA, nrow = 100, ncol = 4)
for( i in (seq_along(lambda0))){
  StdWTestValues[i,]<-apply(t(replicate(100, doublePoisProblem(h, n, m, lambda, lambda0[i], "StdW"))), 2, mean) 
}
plot(lambda0, StdWTestValues[,1])

MCTestValues<-apply(t(replicate(100, doublePoisProblem(h, n, m, lambda, 2, "MC"))), 2, mean) 
MCTestValues


####################

########### Density plot
x<-(0:100)
y<- dpois(x, 2*n)
plot(x,y, type = "l", ylim=c(0,0.08))
abline(v=61.632)
cols<-rainbow(10)
for(i in (1:10)){
  lines(x,dpois(x, n*(1+i/5)),col = cols[i], lwd = 2)
}
lines(x,y, lwd = 2)






### plot the distributions of different lambda0's:
h<-function(y)as.numeric(y$x >= 61.632)
n<-25
m<-10000
lambda<-2
lambda0seq<-seq(1, 4, by = 1e-2)

set.seed(123)
method <- "StdW"
resultMatrix1<-matrix(NA, nrow= length(lambda0seq), ncol=4)
for(i in (1:length(lambda0seq))){
  impSampObj <- doublePoisProblem(h, n, m, lambda, lambda0seq[i], method)
  resultMatrix1[i,] <- ImpSample(impSampObj)$resultVector
}


set.seed(123)
method <- "SimpleW"
resultMatrix2<-matrix(NA, nrow= length(lambda0seq), ncol=4)
for(i in (1:length(lambda0seq))){
  impSampObj <- doublePoisProblem(h, n, m, lambda, lambda0seq[i], method)
  resultMatrix2[i,] <- ImpSample(impSampObj)$resultVector
}

layout(matrix(c(1,2,3,3), 2, 2, byrow = TRUE))
plot(lambda0seq,resultMatrix1[,1], xlab = "lambda0", ylab = "est. mean", main = "Std. weights: Mean")
plot(lambda0seq,resultMatrix2[,1], xlab = "lambda0", ylab = "est. mean", main = "Non-std. weights: Mean")
plot(lambda0seq,log(resultMatrix1[,2]), col = "blue", pch = 19, ylim = c(-13,5), xlab = "lambda0", ylab = "log of est. variance", main = "Log of variance", sub = "blue is std. weights, black is non-std weights")
points(lambda0seq,log(resultMatrix2[,2]), col = "black", pch = 19)
hist(log(resultMatrix1[,2]))
plot(resultMatrix1[,2])
par(mfrow=c(1,1))

tmp1 <- resultMatrix1[,2]
tmp11 <- (lambda0seq>2)
tmp11 <- as.logical(tmp11*(lambda0seq<3))
tmp1 <- tmp1[tmp11]
min1 <- tmp1[tmp1==min(tmp1)]
lmin1<-lambda0seq[tmp1==min(tmp1)]
lmin1<- lmin1[2<lmin1]
lmin1<- lmin1[lmin1<3]

tmp2 <- resultMatrix2[,2]
tmp22 <- (lambda0seq>2)
tmp22 <- as.logical(tmp22*(lambda0seq<3))
tmp2 <- tmp2[tmp22]
min2 <- tmp2[tmp2==min(tmp2)]
lmin2<-lambda0seq[tmp2==min(tmp2)]
lmin2<- lmin2[2<lmin2]
lmin2<- lmin2[lmin2<3]



#### Smaller lambda0 range
h<-function(y)as.numeric(y$x >= 61.632)
n<-25
m<-10000
lambda<-2
lambda0seq<-seq(2, 3, by = 1e-2)

set.seed(123)
method <- "StdW"
resultMatrix1<-matrix(NA, nrow= length(lambda0seq), ncol=4)
for(i in (1:length(lambda0seq))){
  impSampObj <- doublePoisProblem(h, n, m, lambda, lambda0seq[i], method)
  resultMatrix1[i,] <- ImpSample(impSampObj)$resultVector
}
plot(lambda0seq,resultMatrix1[,1])
plot(lambda0seq,log(resultMatrix1[,2]))



set.seed(123)
method <- "SimpleW"
resultMatrix2<-matrix(NA, nrow= length(lambda0seq), ncol=4)
for(i in (1:length(lambda0seq))){
  impSampObj <- doublePoisProblem(h, n, m, lambda, lambda0seq[i], method)
  resultMatrix2[i,] <- ImpSample(impSampObj)$resultVector
}
plot(lambda0seq,resultMatrix2[,1])
plot(lambda0seq,log(resultMatrix2[,2]))


########## Time vs sigmahat^2
h<-function(y)as.numeric(y$x >= 61.632)
n<-25
m<-10000
lambda<-2
lambda0seq<-seq(1.5, 3, by = 1e-2)



method <- "StdW"
resultMatrix1<-matrix(NA, nrow= length(lambda0seq), ncol=4)
set.seed(123)
for(i in (1:length(lambda0seq))){
  impSampObj <- doublePoisProblem(h, n, m, lambda, lambda0seq[i], method)
  resultMatrix1[i,] <- ImpSample(impSampObj)$resultVector
}
plot(lambda0seq,resultMatrix1[,1])
plot(lambda0seq,log(resultMatrix1[,2]))



method <- "SimpleW"
resultMatrix2<-matrix(NA, nrow= length(lambda0seq), ncol=4)
set.seed(123)
for(i in (1:length(lambda0seq))){
  impSampObj <- doublePoisProblem(h, n, m, lambda, lambda0seq[i], method)
  resultMatrix2[i,] <- ImpSample(impSampObj)$resultVector
}
plot(lambda0seq,resultMatrix2[,1])
plot(lambda0seq,log(resultMatrix2[,2]))

microList1<-list()
method <- "StdW"
set.seed(123)
for(i in (1:length(lambda0seq))){
  impSampObj <- doublePoisProblem(h, n, m, lambda, lambda0seq[i], method)
  microList1[[i]] <- summary(microbenchmark(ImpSample(impSampObj)$resultVector, unit = "ms"))
}

microList2<-list()
method <- "StdW"
set.seed(123)
for(i in (1:length(lambda0seq))){
  impSampObj <- doublePoisProblem(h, n, m, lambda, lambda0seq[i], method)
  microList2[[i]] <- summary(microbenchmark(ImpSample(impSampObj)$resultVector, unit = "ms"))
}

tmp1<-do.call(rbind, microList1)
tmp2<-do.call(rbind, microList1)
microListFinal<-rbind(tmp1,tmp2)

plot(tmp1[,5],log(resultMatrix1[,2]), type = "l", ylim=c(-13,0))
lines(tmp2[,5],log(resultMatrix2[,2]), type = "l")



rbind(tmp3[,c(1,4,5)],tmp4[,c(1,4,5)])

#Microbenchmarks
h<-function(y)as.numeric(y$x >= 61.632)
n<-25
m<-10000
lambda<-2
lambda0<-2.295
#method <- "StdW"
#impSampObj <- doublePoisProblem(h, n, m, lambda, lambda0, method)
#profvis(ImpSample(impSampObj))

impSampObj1 <- doublePoisProblem(h, n, m, lambda, lambda0, "MC")
impSampObj2 <- doublePoisProblem(h, n, m, lambda, lambda0, "SimpleW")
impSampObj3 <- doublePoisProblem(h, n, m, lambda, lambda0, "StdW")
impSampObj4 <- doublePoisProblem(h, n, m, lambda, lambda0, "StdWRcpp")

tmp<-microbenchmark(ImpSample(impSampObj1),
                    ImpSample(impSampObj2),
                    ImpSample(impSampObj3),
                    ImpSample(impSampObj4))
tmp2<-summary(tmp)[,c(1,4,5)]

simTiming<-microbenchmark(rpois(10000,1),
                          rpois(10000,2),
                          rpois(10000,5),
                          rpois(10000,10),
                          rpois(10000,20),
                          rpois(10000,50),
                          rpois(10000,100),
                          rpois(10000,1000))


##########

h<-function(y)as.numeric(y$x >= 61.632)
n<-25
lambda<-2
lambda0StdW <- 2.09
lambda0SimpleW <- 2.5
mSeq <- seq(1e3,1e6, by = 1e3)

set.seed(123)
method <- "StdW"
resultMatrix1<-matrix(NA, nrow= length(mSeq), ncol=2)
for(i in (1:length(mSeq))){
  impSampObj <- doublePoisProblem(h, n, mSeq[i], lambda, lambda0StdW, method)
  resultMatrix1[i,2] <- sqrt(ImpSample(impSampObj)$resultVector[2]/mSeq[i])
  resultMatrix1[i,1] <- summary(microbenchmark(ImpSample(impSampObj), unit = "us"))[,5]
}
plot(resultMatrix1[,1], log(resultMatrix1[,2]))

set.seed(123)
method <- "SimpleW"
resultMatrix2<-matrix(NA, nrow= length(mSeq), ncol=2)
for(i in (1:length(mSeq))){
  impSampObj <- doublePoisProblem(h, n, mSeq[i], lambda, lambda0StdW, method)
  resultMatrix2[i,2] <- sqrt(ImpSample(impSampObj)$resultVector[2]/mSeq[i])
  resultMatrix2[i,1] <- summary(microbenchmark(ImpSample(impSampObj), unit = "us"))[,5]
}

set.seed(123)
method <- "MC"
resultMatrix3<-matrix(NA, nrow= length(mSeq), ncol=2)
for(i in (1:length(mSeq))){
  impSampObj <- doublePoisProblem(h, n, mSeq[i], lambda, lambda0StdW, method)
  resultMatrix3[i,2] <- sqrt(ImpSample(impSampObj)$resultVector[2]/mSeq[i])
  resultMatrix3[i,1] <- summary(microbenchmark(ImpSample(impSampObj), unit = "us"))[,5]
}

plot(resultMatrix1[,1], log(resultMatrix1[,2]), col="red", pch = 19,xlim=c(0,30000), ylim=c(-14,-3))
points(resultMatrix2[,1], log(resultMatrix2[,2]), col="blue", pch = 19)
points(resultMatrix3[,1], log(resultMatrix3[,2]), col="black", pch = 19)

plot(resultMatrix1[,1], log(resultMatrix1[,2]), col="red", type = "l",xlim=c(0,30000), ylim=c(-14,-3), lwd = 2, xlab="Time",ylab="Std. error", main = "Standard Error vs Time for different methods", sub="black is MC, blue is non-std. weights and red is std. weights")
lines(resultMatrix2[,1], log(resultMatrix2[,2]), col="blue", lwd = 2)
lines(resultMatrix3[,1], log(resultMatrix3[,2]), col="black", lwd = 2)




##################
plot(x,y,type="n", xaxt="n", yaxt="n")


abline(v=61.632)
y2<- dpois(x, 3*n)




plot(x,y,type="n", xaxt="n", yaxt="n")
my.legend.size <-legend("topright",c("Series1","Series2","Series3"),plot = FALSE)

#custom ylim. Add the height of legend to upper bound of the range
my.range <- range(y)
my.range[2] <- 1.04*(my.range[2]+my.legend.size$rect$h)

#draw the plot with custom ylim
plot(x,y,ylim=my.range, type="l")
my.legend.size <-legend("topright",c("Series1","Series2","Series3"))











