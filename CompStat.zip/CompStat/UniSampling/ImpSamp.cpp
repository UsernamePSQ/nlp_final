#include <Rcpp.h>

// [[Rcpp::export]]
List ImpSampleStdWRcpp(List y){
  NumericVector resultVector(4);
  Function h = as<Function>(y["h"]);
  NumericVector hValues = h(y);
  NumericVector x = as<NumericVector>(y["x"]);
  int m = x.size();
  NumericVector wstarValues(m);
  for(int it = 0; it < m; ++it) {
    wstarValues(it) = pow(as<double>(y["lambda"])/as<double>(y["lambda0"]), x(it)) * 
                          exp(as<double>(y["lambda0"])-as<double>(y["lambda"]));
  }
  NumericVector wValues = wstarValues/sum(wstarValues);
  resultVector(0) = sum(hValues * wValues);
            NumericVector tmpProd = hValues * wstarValues;
            double varIS = var(tmpProd);
            double varWstar = var(wstarValues);
            double gamma = (1/(m - 1)) * sum((tmpProd - mean(tmpProd))*(wstarValues - mean(wstarValues))); 
            resultVector(1) = round((varIS+resultVector[1]*varWstar-2*resultVector[1]*gamma)/m*1e10)/1e10;
            double tmp = 1.96 * sqrt(resultVector(1) / m);
            resultVector(2) = resultVector(0) - tmp;
            resultVector(3) = resultVector(0) + tmp;
            y["resultVector"] = resultVector;
  return y;
}  