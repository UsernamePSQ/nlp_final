library("ggplot2")
library("reshape2")
library('microbenchmark')
library('ggplot2')
library('profvis')
library('Rcpp')

wstar <- function(y, ...){
  UseMethod("wstar")
}

w <- function(y, ...){
  UseMethod("w")
}

wstar.doublePois <- function(y){
  ((y$lambda / y$lambda0)^y$x) * exp(y$lambda0 - y$lambda)
}

wstar.default <- function(y, ...){
  y$f(y$x, ...) / y$g(y$x, ...)
}

w.default <- function(y, ...){
  tmp <- wstar(y, ...) 
  return(tmp / sum(tmp))
}

ImpSample <- function(y){
  y$resultVector <- rep(NA, 4)
  y$hValues <- y$h(y)
  
  y <- MeanVar(y)
  
  tmp <- 1.96 * sqrt(y$resultVector[2])
  y$resultVector[3] <- y$resultVector[1] - tmp
  y$resultVector[4] <- y$resultVector[1] + tmp
  return(y)
}
 
MeanVar <- function(y){
  UseMethod("MeanVar")
}

MeanVar.StdW <- function(y){
  wValues <- w(y)
  y$resultVector[1] <- sum(y$hValues * wValues)
  #sigmahat^2
  wstarValues <- wstar(y)
  tmpProd <- y$hValues * wstarValues
  varIS <- var(tmpProd)
  varWstar <- var(wstarValues)
  gamma <- cov(tmpProd, wstarValues)
  y$resultVector[2] <- round((varIS + y$resultVector[1]^2 * varWstar - 2 * y$resultVector[1] * gamma) / y$m, digits = 10)
  return(y)
}
  
MeanVar.SimpleW <- function(y){
  wstarValues <- wstar(y)
  y$resultVector[1] <- mean(y$hValues * wstarValues)
  #sigmahat^2      
  y$resultVector[2] <- var(y$hValues * wstarValues)/y$m
  y$weights <- wstarValues
  return(y)
}
MeanVar.MC <- function(y){
  y$resultVector[1] <- mean(y$hValues)
  #sigmahat^2
  y$resultVector[2] <- var(y$hValues)/y$m
  return(y)
}

doublePoisProblem <- function(h, n, m, lambda, lambda0 = lambda, method, x){
  if (missing(x)) x <- rpois(m, n*lambda0)
  ImpSampObj<-structure(list(h = h, x = x, lambda = n*lambda, lambda0 = n*lambda0, m = m), 
                                                      class = c("doublePois", method))
  return(ImpSampObj)
}


cppFunction('List ImpSampleStdWRcpp(List y){
  NumericVector resultVector(4);
            Function h = as<Function>(y["h"]);
            NumericVector hValues = h(y);
            NumericVector x = as<NumericVector>(y["x"]);
            int m = x.size();
            NumericVector wstarValues(m);
            for(int it = 0; it < m; ++it) {
            wstarValues(it) = pow(as<double>(y["lambda"])/as<double>(y["lambda0"]), x(it)) *
            exp(as<double>(y["lambda0"])-as<double>(y["lambda"]));
            }
            NumericVector wValues = wstarValues/sum(wstarValues);
            resultVector(0) = sum(hValues * wValues);
            NumericVector tmpProd = hValues * wstarValues;
            double varIS = var(tmpProd);
            double varWstar = var(wstarValues);
            double gamma = (1/(m - 1)) * sum((tmpProd - mean(tmpProd))*(wstarValues - mean(wstarValues)));
            resultVector(1) = round((varIS+pow(resultVector[1], 2)*varWstar-2*resultVector[1]*gamma)/m*1e10)/1e10;
            double tmp = 1.96 * sqrt(resultVector(1));
            resultVector(2) = resultVector(0) - tmp;
            resultVector(3) = resultVector(0) + tmp;
            y["resultVector"] = resultVector;
            return y;
            }')

