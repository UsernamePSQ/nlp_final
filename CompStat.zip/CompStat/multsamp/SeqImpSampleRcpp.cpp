// [[Rcpp::depends(RcppArmadillo)]]

#include <RcppArmadilloExtensions/sample.h>
using namespace Rcpp;

// [[Rcpp::export]]
List SeqImpSampleRcpp(NumericVector y, int m, double tol,double x0, double a, double b, double sigma) {
  int t = y.size();
  NumericMatrix x(m, t, x0), u(m, t, 1/m), w(m, t, 1/m);
  double gamma = (a + b) / 2;
  NumericVector xhat(t, x0);
  NumericVector tmp, minv(m, 1/m);
  NumericVector factorialY = factorial(y);
  IntegerVector indices = seq_len(m) - 1;
  IntegerVector resamp(m);
  
  int count = 0;
  
  for(int s = 1; s < t - 1; s++) {
    tmp = a*(x(_,t-1) <= gamma)+b*(x(_,t-1) > gamma);
    x(_, s) = pmax(tmp, 1);
    u(_, s) = pow(x(_, s), y(s)) * exp( - x(_, s)) / factorialY;
    w(_, s) = u(_, s)/sum(u(_, s));
    double nhat = 1/sum(pow(w(_, s),2));
    if (nhat < tol * m) {
      NumericVector ww = w(_, s);
      resamp = RcppArmadillo::sample(indices, m, true, ww);
      for(int k = 0; k < m; k++){
      x(k, s) = x(resamp(k), s);
      }
      w(_, s) = minv;
      count += 1;
    }
    xhat(s) = sum(x(_, s) * w(_, s));
  }
  
  List ret; ret["xhat"] = x; ret["weights"] = w(_, t-1); ret["count"] = count;
  return ret;   
}