library(Rcpp)

noBootSeqImpSamp<-function(y,x0,n,rho,sigmaD,sigmaE){
  t <- length(y)
  x <- matrix(NA, n, t)
  wstar <- matrix(NA, n, t)
  w <- matrix(NA, n, t)
  
  x[,1] <- x0
  wstar[,1] <- dnorm(y[1], x0, sigmaD)
  w[,1] <- wstar[,1] / sum(wstar[,1])
  
  for(s in (2:t)){
    x[, s] <- x[,s-1] + rnorm(n, rho^(s-1)*x0, sigmaE)
    wstar[, s] <- w[, s-1] * dnorm(y[s], x[, s], sigmaD)
    w[, s] <- wstar[, s]/sum(wstar[, s])
  }
  return(x,w)
}

BootSeqImpSamp<-function(y,x0,n,rho,sigmaD,sigmaE){
  t <- length(y)
  x <- matrix(NA, n, t)
  u <- matrix(NA, n, t)

  x[,1] <- x0

  for(s in (2:t)){
    x[, s] <- x[,s-1] + rnorm(n, rho^(s-1)*x0, sigmaE)
    u[, s] <- dnorm(y[s], x[, s], sigmaD) #unfinished? w[, s-1] *?
    x[, s] <- sample(x[, s], n, replace = TRUE, prob = u[, s])
  }
  return(x)
}

  cppFunction('NumericMatrix CBootSeqImpSamp(NumericVector y, double x0, int n, double rho, double sigmaD, double sigmaE) {
              int            t =  y.size();
              NumericMatrix  x(n, t);
              NumericMatrix  u(n, t);

              for(int m = 0; m < n; m++){
              x(m,0) = x0;
              }
    
              for(int s=1; s<t; s++){
                for(int m = 0; m < n; m++){
                x(m, s) = x(m,s-1) + rnorm(n, pow(rho,(s-1))*x0, sigmaE);
                u(m, s) = dnorm(y[s], x(m, s), sigmaD);
                x(m, s) = sample(x(m, s), n, replace = TRUE, prob = u(m, s));
                }
              }
              return(x);
              }')

t<-10
xtrue<-rnorm(t,0,1)
y<-xtrue+rnorm(t,0,0.2)
x0<-y[1]
n<-1000
rho<-0.9
sigmaD<-1
sigmaE<-1

tmp<-BootSeqImpSamp(y,x0,n,rho,sigmaD,sigmaE)
dim(tmp)
apply(tmp,2,mean)
plot(1:10,xtrue)
lines(1:10,apply(tmp,2,mean),col='blue')
lines(1:10,y,col='red')
# plot(1:10,y)


cppFunction('NumericMatrix CBootSeqImpSamp(NumericVector y, double x0, int n, double rho, double sigmaD, double sigmaE) {
            int            t =  y.size();
            NumericMatrix  x(n, t);
            NumericMatrix  u(n, t);
            
            x(,0) <- x0;
            
            for(int s=1; s<t; s++){
            x(, s) = x(,s-1) + rnorm(n, pow(rho,(s-1))*x0, sigmaE);
            u(, s) = dnorm(y[s], x(, s), sigmaD);
            x(, s) = sample(x(, s), n, replace = TRUE, prob = u(, s));
            }
            return(x);
            }')
