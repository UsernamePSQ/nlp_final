library('microbenchmark')
library('ggplot2')
library('profvis')
library('Rcpp')
library("compiler")
SimObj<-assignClassSim(x0=5, a=5, b=20, sigma=3, n=1000)

sim<-FullSim(SimObj)
sim

plot(sim$x, type = "l", lwd = 1)

impSampObj<-list(y=sim$y, x0=5, a=5, b=20, sigma=3)
impSampObj<-assignClassImpSamp(impSampObj)



SeqImpSampTest<-SeqImpSamp(impSampObj, 1000, 1)
SeqImpSampTest$count

plot(sim$x, type = "l", lwd = 1)
lines(SeqImpSampTest$xhat, col = "blue")


sum((SeqImpSampTest$xhat-sim$x>0))

plot(sim$x,SeqImpSampTest$xhat)

#Tests:
### Simple correctness check????
### Lav a, b, s� altid 1
SimObj<-list()
set.seed(123)
SimObj<-assignClassSim(x0=1, a=0.1, b=0.3, sigma=0.4, n=100)
sim<-FullSim(SimObj)


impSampObj<-assignClassImpSamp(y=sim$y, x0=1, a=0.1, b=0.2, sigma=0.4)
SeqImpSampTest<-SeqImpSamp(impSampObj, 1000, 1)

plot(sim$x, type = "l")
lines(SeqImpSampTest$xhat, col="blue")

### H�j a,b, s� aldrig 1

set.seed(123)
SimObj<-assignClassSim(x0=10, a=10, b=20, sigma=3, n=100)
sim<-FullSim(SimObj)


impSampObj<-assignClassImpSamp(y=sim$y, x0=10, a=10, b=20, sigma=3)

SeqImpSampTest<-SeqImpSamp(impSampObj, 1000, 1)

plot(sim$x, type = "l")
lines(SeqImpSampTest$xhat, col="blue")


####Blanding
set.seed(213)

SimObj<-assignClassSim(x0=1, a=0.5, b=1.5, sigma=0.3, n=100)
sim<-FullSim(SimObj)

impSampObj<-assignClassImpSamp(y=sim$y, x0=1, a=0.5, b=1.5, sigma=0.3)
SeqImpSampTest<-SeqImpSamp(impSampObj, 1000, 1)

plot(sim$x, type = "l")
lines(SeqImpSampTest$xhat, col="blue")

### Test of different tols
SimObj<-list(x0=10, a=10, b=20, sigma=3, n=1000)
SimObj<-assignClassSim(SimObj)
sim<-FullSim(SimObj)

impSampObj<-list(y=sim$y, x0=10, a=10, b=20, sigma=3)
impSampObj<-assignClassImpSamp(impSampObj)

SeqImpSampTest1<-SeqImpSamp(impSampObj, 1000, 0)
SeqImpSampTest1$count

countTest<-rep(NA,10)
xMatrix <- matrix(NA, nrow = 1001, ncol = 11)
for( i in (0:10)){
  tmp<-SeqImpSamp(impSampObj, 1000, i/10)
  countTest[i+1] <- tmp$count
  xMatrix[,i+1] <- tmp$xhat
}

cols<-terrain.colors(11)
plot(sim$x, type = "l")
for(i in (1:11)){
  print(mean(abs(xMatrix[,i]-sim$x)))
} 
par(mfrow=c(3,1))
plot(sim$x, type = "l")
lines(xMatrix[,1], col = "blue")
plot(sim$x, type = "l")
lines(xMatrix[,2], col = "blue")
plot(sim$x, type = "l")
lines(xMatrix[,11], col = "blue")
par(mfrow=c(1,1))

plot(xMatrix[,2]-xMatrix[,11])
### H�j a,b, s� aldrig 1
SimObj<-list(x0=10, a=10, b=20, sigma=3, n=1000)
SimObj<-assignClassSim(SimObj)
sim<-FullSim(SimObj)

impSampObj<-list(y=sim$y, x0=10, a=10, b=20, sigma=3)
impSampObj<-assignClassImpSamp(impSampObj)

countTest<-rep(NA,10)
xMatrix <- matrix(NA, nrow = 1001, ncol = 101)
for( i in (0:100)){
  tmp<-SeqImpSamp(impSampObj, 1000, i/100)
  countTest[i+1] <- tmp$count
  xMatrix[,i+1] <- tmp$xhat
}

cols<-terrain.colors(11)
par(mfrow=c(1,2))
plot(sim$x, type = "l")d
lines(xMatrix[,1], col = "blue")
plot(sim$x, type = "l")
lines(xMatrix[,2],col = "red")

meanSave <- rep(NA,101)
for(i in (1:101)){
  meanSave[i]<-mean(abs(xMatrix[,i]-sim$x))
} 
plot(meanSave)
##############
# SMC dataset
sourceCpp("testcpp.cpp")
data<-read.table("SMC.txt", header = T)
plot(data, type = "l")
e<-matrix(rnorm(length(data$y-1 )*(1000), 0, 3), nrow = 1000, ncol = (length(data$y-1)))
test<-seqImpSampleRcpp(data$y, 1, 5, 20, 3, 1000)
cppFunction('NumericVector vectorN(int N, double a, double b) { return rnorm(N,a ,b); }')
plot(test$xhat, type = "l", col = "blue")

impSampObj<-assignClassImpSamp(y=data$y, x0=1, a=5, b=20, sigma = 3)
SeqImpSampResults<-SeqImpSamp(impSampObj, 1000, 0.01)
SeqImpSampResults$count
plot(SeqImpSampResults$xhat, type = "l", col = "blue")
hist(log(SeqImpSampResults$weights))
plot(log(SeqImpSampResults$weights))
######
impSampObj<-assignClassImpSamp(y=data$y, x0=1, a=5, b=20, sigma = 3)
par(mfrow=c(3,3))
for(i in (0:5)){
SeqImpSampResults<-SeqImpSamp(impSampObj, 100, 1)
plot(SeqImpSampResults$xhat, type = "l", col = "blue")
}
par(mfrow=c(1,1))
set.seed(123)
layout(matrix(c(1,1,1,2,2,2,3,3,4,4,5,5), 2, 6, byrow = TRUE))
SeqImpSampResults<-SeqImpSamp(impSampObj, 100, )
plot(SeqImpSampResults$xhat, type = "l", col = "blue")
SeqImpSampResults<-SeqImpSamp(impSampObj, 100, 1)
plot(SeqImpSampResults$xhat, type = "l", col = "blue")
SeqImpSampResults<-SeqImpSamp(impSampObj, 300, 1)
plot(SeqImpSampResults$xhat, type = "l", col = "blue")
SeqImpSampResults<-SeqImpSamp(impSampObj, 1000, 1)
plot(SeqImpSampResults$xhat, type = "l", col = "blue")
SeqImpSampResults<-SeqImpSamp(impSampObj, 10000, 1)
plot(SeqImpSampResults$xhat, type = "l", col = "blue")
par(mfrow=c(1,1))

par(mfrow=c(2,3))
set.seed(123)
SeqImpSampResults<-SeqImpSamp(impSampObj, 100, 0)
SeqImpSampResults$count
plot(SeqImpSampResults$xhat, type = "l", col = "blue")
SeqImpSampResults<-SeqImpSamp(impSampObj, 100, 0.02)
SeqImpSampResults$count
plot(SeqImpSampResults$xhat, type = "l", col = "blue")
SeqImpSampResults<-SeqImpSamp(impSampObj, 100, 0.05)
SeqImpSampResults$count
plot(SeqImpSampResults$xhat, type = "l", col = "blue")
SeqImpSampResults<-SeqImpSamp(impSampObj, 100, 0.1)
SeqImpSampResults$count
plot(SeqImpSampResults$xhat, type = "l", col = "blue")
SeqImpSampResults<-SeqImpSamp(impSampObj, 100, 0.2)
SeqImpSampResults$count
plot(SeqImpSampResults$xhat, type = "l", col = "blue")
SeqImpSampResults<-SeqImpSamp(impSampObj, 100, 1)
SeqImpSampResults$count
plot(SeqImpSampResults$xhat, type = "l", col = "blue")
par(mfrow=c(1,1))

####
sourceCpp("SeqImpSampleRcpp.cpp")
sourceCpp("testcpp.cpp")
sourceCpp("SMC.cpp")
### Profile?
profvis(SeqImpSamp(impSampObj, 1000, 1))

### Benchmark different tol - look at difference in time with often resample vs not so vs never + maybe look into results? 
#tol
length(seq(0,0.1,by=0.01))
#m
length(seq(100, 1000, by = 100))

impSampObj<-assignClassImpSamp(y=data$y, x0=1, a=5, b=20, sigma = 3)
microList<-list()
index<-matrix(1:(5*14),ncol = 5, nrow = 14, byrow = F)

k<- l <- 1
for(i in c((1:3),5,10)){
  for( j in c((1:11),21,51,101)){
    microList[[index[l,k]]] <- summary(microbenchmark(SeqImpSamp(impSampObj, i*100, (j-1)/10), unit = "ms", times = 50))
    cat("l =", l, "k =", k, "\n")
    l <- l+1
  }
l<-1
k<-k+1
}
microList2<-list()
for(i in (1:length(microList))){
  microList2[i] <- microList[[i]][,5]
}

length(microList2)


newMicroList<-list()
index<-rep((1:5),each=14)
for(i in (1:5)){
  newMicroList[[i]] <- do.call(rbind, microList2[(index==i)])
}


plot(rep(100,14),newMicroList[[1]], xlim = c(80,1000), ylim = c(60,450), xlab = "m", ylab = "time in ms", main = "Time vs m for different tols")
axis(1, at = seq(100, 1000, by = 200), las=1)
j<-2
for(i in c((2:3),5,10)*100){
points(rep(i,14),newMicroList[[j]])
j = j+1
}

for(i in (1:5)){
print((max(newMicroList[[i]])-min(newMicroList[[i]]))/min(newMicroList[[i]]))
}
for(i in (1:5)){
  print(mean(newMicroList[[i]]))
}



## CMP
source("AssignmentFunctions.R")
cmpfile("AssignmentFunctions.R")
loadcmp("AssignmentFunctions.Rc")


cmpmiclist<-list()
cmpmiclist[[1]]<-summary(microbenchmark(SeqImpSamp(impSampObj, 100, 0),
                                        SeqImpSamp(impSampObj, 100, 0.02),
                                        SeqImpSamp(impSampObj, 100, 0.5),
                                        SeqImpSamp(impSampObj, 100, 1),
                                        SeqImpSamp(impSampObj, 1000, 0),
                                        SeqImpSamp(impSampObj, 1000, 0.02),
                                        SeqImpSamp(impSampObj, 1000, 0.5),
                                        SeqImpSamp(impSampObj, 1000, 1),
                                        unit = "ms", times = 100))
cmpmiclist[[1]][,1]<-c("Cmp: m = 100, tol = 0", "Cmp: m = 100, tol = 0.02", "Cmp: m = 100, tol = 0.5",
                       "Cmp: m = 100, tol = 1", "Cmp: m = 1000, tol = 0", "Cmp: m = 1000, tol = 0.02", 
                       "Cmp: m = 1000, tol = 0.5", "Cmp: m = 1000, tol = 1")
remove(list = lsf.str())
source("AssignmentFunctions.R") 
cmpmiclist[[2]]<-summary(microbenchmark(SeqImpSamp(impSampObj, 100, 0),
                                        SeqImpSamp(impSampObj, 100, 0.02),
                                        SeqImpSamp(impSampObj, 100, 0.5),
                                        SeqImpSamp(impSampObj, 100, 1),
                                        SeqImpSamp(impSampObj, 1000, 0),
                                        SeqImpSamp(impSampObj, 1000, 0.02),
                                        SeqImpSamp(impSampObj, 1000, 0.5),
                                        SeqImpSamp(impSampObj, 1000, 1),
                                        unit = "ms", times = 100))
cmpmiclist[[2]][,1]<-c("m = 100, tol = 0", "m = 100, tol = 0.02", "m = 100, tol = 0.5",
                       "m = 100, tol = 1", "m = 1000, tol = 0", "m = 1000, tol = 0.02", 
                       "m = 1000, tol = 0.5", "m = 1000, tol = 1")
rbindlist<-list(cmpmiclist[[2]],cmpmiclist[[1]])
cmpmiclistFinal<-do.call(rbind,rbindlist)

cmpmiclist[[3]]<-summary(microbenchmark(SeqImpSamp(impSampObj, 100, 0),
                                        SeqImpSamp(impSampObj, 100, 0.02),
                                        SeqImpSamp(impSampObj, 100, 0.5),
                                        SeqImpSamp(impSampObj, 100, 1),
                                        SeqImpSamp(impSampObj, 1000, 0),
                                        SeqImpSamp(impSampObj, 1000, 0.02),
                                        SeqImpSamp(impSampObj, 1000, 0.5),
                                        SeqImpSamp(impSampObj, 1000, 1),
                                        unit = "ms", times = 100))

##################







###
#if  (max(!(c("x0", "a", "b", "mu", "sigma", "n") %in% names(z)))){stop(paste("List does not contain correct arguments."))}
#if ((z$n!=round(z$n)) ||  (z$n<1)){stop(paste("n must be an integer"))}
#if (max(!(c("x0", "a", "b", "mu", "sigma", "y") %in% names(z)))){stop(paste("List does not contain correct arguments."))}
#if (length(z$y) < 2){stop(paste("y must have length at least 2"))}




# cppFunction('NumericVector test(NumericMatrix x, double b, double a, double gamma, double sigma ) {
#   NumericVector ret;
#   ret = max(a * (x(1, 2) <= gamma) + b * (x(1, 2) > gamma) + rnorm(1, 0 , sigma),1);
#   return ret;
# }')
# 
# x<-matrix(1:4,ncol=2)
# test(a,2)
# test(c(2,3),c(3,1))
# 
# test(x, 3, 1, 2, 1)
# a * (x(k, s-1) <= gamma) + b * (x(k, s-1) > gamma) + rnorm(1, 0 , sigma);
