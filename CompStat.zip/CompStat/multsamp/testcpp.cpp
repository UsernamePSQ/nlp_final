#include <RcppArmadilloExtensions/sample.h>
// [[Rcpp::depends(RcppArmadillo)]]


using namespace Rcpp;
// [[Rcpp::export]]

List seqImpSampleRcpp(NumericVector y, double x0, double a, double b, double sigma, int m)
{
  int s = y.size();
  double gamma = (a+b)/2;
  NumericMatrix w(m, s), x(m, s);
  NumericVector tmp(m);
  IntegerVector resamp(m);
  NumericVector uu;
  NumericVector factY = factorial(y);
  IntegerVector indices = seq_len(m) - 1;
  NumericVector xhat(s);
  NumericVector e1 = rnorm(m*(s-1), 0, sigma);
  NumericMatrix e(m, s - 1, e1.begin());
  
  for(int k = 0; k < m; k++){
    x(k,0) = x0;
    w(k, 0) = 1.0/m;
  }
  xhat(0) = x0;

  for (int t = 1; t < s; t++){
    tmp = a * (x(_,t-1) <= gamma) + b * (x(_,t-1) > gamma);
    x(_,t) = pmax(tmp + e(_, t-1) ,1);
    w(_,t) = exp(-x(_,t)) * pow( x(_,t), y(t) ) / factY(t);
    w(_,t) = w(_,t)/sum(w(_,t));
    uu = w(_,t);           
    resamp = RcppArmadillo::sample(indices, m, true, uu);
    for(int k = 0; k < m; k++){
      x(k,t) = x(resamp(k),t);
      w(k, t) = 1.0/m;
    }
    xhat(t) = sum((w(_,t)*x(_,t)));
  }
  List ret; ret["xhat"] = xhat;
  return(ret);
}