Noise<-function(z, ...){
  UseMethod("Noise")
}

Noise.NoiseAssign<-function(z, x){
  rnorm(length(x), mean = 0, sd = z$sigma)
}

ObservedFunc<-function(z, ...){
  UseMethod("ObservedFunc")
}

ObservedFunc.ObservedSimAssign<-function(z){
  rpois(length(z$x), z$x)
}

ObservedFunc.ObservedImpSampAssign<-function(z, i, x){
  dpois(z$y[i], x)
}

UpdateFunc<-function(z, ...){
  UseMethod("UpdateFunc")
}

UpdateFunc.HiddenAssign<-function(z, x){
  pmax(z$a * (x <= z$gammaAssign) + z$b * (x > z$gammaAssign) + Noise(z, x), rep(1, length(x)))
}


assignClassSim<-function(x0, a, b, sigma, n){
 z <- structure(list(x0 = x0, a = a, b = b, sigma = sigma, n = n, x = c(x0,rep(NA,n))
                , gammaAssign = (a+b)/2), class = c("HiddenAssign", "ObservedSimAssign", "NoiseAssign"))
  return(z)
}

assignClassImpSamp<-function(y, x0, a, b, sigma){
  z <- structure(list(y = y, x0 = x0, a = a, b = b, sigma = sigma, gammaAssign = (a+b)/2),
                         class = c("HiddenAssign", "ObservedImpSampAssign", "NoiseAssign"))
  return(z)
}

FullSim<-function(z){
  for(i in (2:length(z$x))){
    z$x[i]<-UpdateFunc(z, z$x[i-1])
  }
  z$y<-ObservedFunc(z)
  return(z)
}

SeqImpSamp<-function(z, m, Tol=0.3){
  t <- length(z$y)
  x <- matrix(NA, m, t)
  u <- matrix(NA, m, t)
  w <- matrix(NA, m, t)
  
  x[, 1] <- z$x0
  u[, 1] <- w[, 1] <- 1/m
  
  count <- 0
  for(s in (2:t)){
    x[, s] <- UpdateFunc(z, x[, s-1])
    u[, s] <- w[, s-1] * ObservedFunc(z, s, x[, s-1])
    w[, s] <- u[, s]/sum(u[, s])
    nhat <- 1/sum(w[, s]^2)
    if (nhat< Tol * m) {
      x[, s] <- sample(x[, s], size = m, replace = T, prob = w[, s])
      w[, s] <- 1/m
      count <- count + 1
    }
  }
  z$count <- count
  z$weights <- w[, t]
  z$xhat<-colSums(x * w)
  return(z)
}
