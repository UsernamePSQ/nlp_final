## Define density of x
fx <- function(x, theta) theta[5]*dnorm(x, theta[1], sqrt(theta[3])) + (1 - theta[5])*dnorm(x, theta[2], sqrt(theta[4]))
## Define density of y = (x, z)
fy <- function(x, z, theta) (z == 1)*theta[5]*dnorm(x, theta[1], sqrt(theta[3])) + (z == 0)*(1 - theta[5])*dnorm(x, theta[2], sqrt(theta[4]))

norm_vec <- function(x) sqrt(sum(x^2))

Q <- function(x, theta){
  ## Description: Calculates conditional expected value of log-likelihood 
  ##              for Gaussian mixture model given observed vector data x 
  ##              and parameters theta.
  ## Parameters:
  ##    x:      Observed data
  ##    theta:  Model parameters
  ## Output: Value of conditional expectation (scalar).
  if (theta[3] < 0 || theta[4] < 0 || theta[5] <= 0 || theta[5] >= 1)
    return(-Inf)
  
  coeff0 <- fy(x, 0, theta) / fx(x, theta)  
  coeff1 <- fy(x, 1, theta) / fx(x, theta)
  
  terms0 <- log(1 - theta[5]) -0.5*log(theta[4]) - 0.5*(x - theta[2])^2 / theta[4] - 0.5*log(2*pi)
  terms1 <- log(theta[5]) -0.5*log(theta[3]) - 0.5*(x - theta[1])^2 / theta[3] - 0.5*log(2*pi)
  
  sum( coeff0*terms0 + coeff1*terms1)
}

EM <- function(x, theta, stopCrit = "rel", tol = 1e-8, maxIter = 50){
  ## Description: Runs EM algorithm for Gaussian Mixture model
  ##              and returns estimated MLE parameters.
  ## Parameters:
  ##    x:          Observed data
  ##    theta:      Initial guess of MLE parameters
  ##    stopCrit:   Type of stopping criteria for algorithm. 
  ##                Options: "abs", "rel"
  ##    tol:        Tolerance level for stopping criteria. 
  ##                Algorithm stops when error is below this number.
  ##    maxIter:    Maximum number of iterations no matter if 
  ##                stopping criteria is met.
  ##    statistics: If true a data frame containing results from
  ##                all iterations is also returned.
  ## Output: List containing estimated MLE parameters and 
  ##         also data frame with results from each iteration.
  if (stopCrit == "abs"){
    errFun <- function(z_1, z_0) norm_vec(z_1 - z_0)
  } else if (stopCrit == "rel"){
    errFun <- function(z_1, z_0) norm_vec(z_1 - z_0) / norm_vec(z_0)
  } else {
    stop(paste("EM:Unsupported: Stop criteria ", stopCrit, " is not supported."))
  }
  
  negLogLik = -Q(x, theta)
  stat = data.frame(0, theta[1],theta[2],theta[3],theta[4],theta[5],NA,negLogLik)
  colnames(stat) <- c("iteration", "mu1","mu2","sigma1", "sigma2", "p", "error", "negLogLik")
  
  i = 1
  err = Inf
  valPrev = negLogLik
  thetaPrev = theta
  while (err > tol && i < maxIter){
    tmp <- optim(theta, function(theta) -Q(x, theta))
    
    if (!is.null(tmp$message)) warning(paste("EM:Optimize warning: Function optim returned warning: ", tmp$message))
    
    theta <- tmp$par
    #err <- errFun(tmp$value, valPrev)
    err <- errFun(theta, thetaPrev)
    valPrev <- tmp$value
    thetaPrev = theta
    
    newRow <- c(i,theta[1],theta[2],theta[3],theta[4],theta[5],err,tmp$value)
    stat = rbind(stat, newRow)
    
    i = i + 1
  }
  if (i >= maxIter){
    warning("EM:Optimize warning: Maximum number of iterations reached")
  }
  list(MLE = theta, statistics = stat)
}

EM_Analytical <- function(x, theta0, stopCrit = "rel", tol = 1e-8, maxIter = 50){
  ## Description: EM algorithm with explicit update of
  ##              parameters using analytical expression.
  if (stopCrit == "abs"){
    errFun <- function(z_1, z_0) norm_vec(z_1 - z_0)
  } else if (stopCrit == "rel"){
    errFun <- function(z_1, z_0) norm_vec(z_1 - z_0) / norm_vec(z_0)
  } else {
    stop(paste("EM:Unsupported: Stop criteria ", stopCrit, " is not supported."))
  }
  
  count <- 1
  theta <- theta0
  err <- Inf
  while (err > tol && count < maxIter){
    thetaPrev <- theta
    Tji <- function(j,i){
      if (j == 1){
          theta[5]*dnorm(x[i],theta[1],sqrt(theta[3]))/(theta[5]*dnorm(x[i],theta[1],sqrt(theta[3]))+(1-theta[5])*dnorm(x[i],theta[2],sqrt(theta[4])))  
      } else if (j == 2){
        (1 - theta[5])*dnorm(x[i],theta[2],sqrt(theta[4]))/(theta[5]*dnorm(x[i],theta[1],sqrt(theta[3]))+(1-theta[5])*dnorm(x[i],theta[2],sqrt(theta[4])))  
      }
    }
    TMatrix <- matrix(NA, nrow = length(x), ncol=2)
    for (j in 1:2){
      for (i in 1:length(x)){
        TMatrix[i,j] <- Tji(j,i)
      }
    }
    
    p <- colMeans(TMatrix)[1]
    
    mu1 <- sum(TMatrix[,1]*x)/(sum(TMatrix[,1]))
    mu2 <- sum(TMatrix[,2]*x)/(sum(TMatrix[,2]))
    sigma1 <- sum(TMatrix[,1]*(x-mu1)^2)/(sum(TMatrix[,1]))
    sigma2 <- sum(TMatrix[,2]*(x-mu2)^2)/(sum(TMatrix[,2]))
    theta <- c(mu1,mu2,sigma1,sigma2,p)
    count <- count + 1
    err <- errFun(theta, thetaPrev)
  }
  list(MLE = theta, nIterations = count, error = err)
}

GMMsim <- function(theta, n){
  ## Description: Simulates from gaussian mixture model given parameters theta.
  ## Parameters:
  ##    theta: Parameters for GMM.
  ##    n:     Number of observations to simulate.
  ## Output: Numeric vector of simulated values.
  Y1 <- rnorm(n, theta[1], theta[3])
  Y2 <- rnorm(n, theta[2], theta[4])
  Z <- (rnorm(n) >= 0)
  Z*Y1 + (1-Z)*Y2
}

FisherInf <- function(Q, x, mle, method = "SEM"){
  ## Description: Estimates observed fisher information for MLE 
  ##              parameters estimated via the EM algorithm.
  ## Parameters:
  ##    Q:      Q - function to optimize, i.e. expected value of
  ##            log-likelihood of complete data vector.
  ##    x:      Observations
  ##    mle:    Estimated MLE parameter vector.
  ##    method: Specifies how to estimate fisher information.
  ##            Options: "
  ##                SEM": Supplemented EM
  ##    ...:    Other parameters for EM algorithm 
  ## Output: Returns numeric length(x) by length(x) matrix.
  require("numDeriv")
  if (method == "SEM"){
    d <- length(mle)
    iY <- hessian(function(par) -Q(x, par) , mle)
    psi_func <- function(par) {
      tmp <- EM(x, par)
      tmp$MLE
    }
    DPsi <- jacobian(psi_func, mle)
    iX <- (diag(1, d) - t(DPsi)) %*% iY
    iYinv <- solve(iY)
    iYinv + iYinv %*% t(solve(diag(1, d) - DPsi, DPsi))
  } else {
    stop(paste("FisherInf:Unsupported: Function does not support method ", method , "" ))
  }
}
