CmpnegloglikFunc<-function(x, theta){
  if(theta[1]<0 || theta[1]>1 || theta[3]<=0 || theta[5]<=0){return(Inf)}
  -sum(log(theta[1] * dnorm(x, theta[2], sqrt(theta[3])) + (1-theta[1]) * dnorm(x, theta[4], sqrt(theta[5]))))
}

CmpMembershipProb<-function(x, z, theta){
  #Calculating the conditional expectation of an indicator of the form (z==0) or (z==1) given x obs and theta
  #CompleteDensity(x, z, theta)/InCompleteDensity(x, theta)
  
  dnorm0 <- dnorm(x, theta[4], sqrt(theta[5]))
  dnorm1 <- dnorm(x, theta[2], sqrt(theta[3]))
  
  
  ((z==1) * theta[1] * dnorm1 + (z==0) * (1-theta[1]) * dnorm0)/
    (theta[1] * dnorm1 +          (1-theta[1]) * dnorm0)
  
}

CmpEStep<-function(x, thetaCond, theta){
  if(theta[1]<0 || theta[1]>1 || theta[3]<=0 || theta[5]<=0){return(Inf)}
  else{
    termsToSum0 <- log(1 - theta[1]) - 0.5 * (log(2*pi) + log(theta[5]) + (x-theta[4])^2/theta[5])
    termsToSum1 <- log(theta[1])     - 0.5 * (log(2*pi) + log(theta[3]) + (x-theta[2])^2/theta[3])
    
    -sum(MembershipProb(x, 0, thetaCond) * termsToSum0 +
           MembershipProb(x, 1, thetaCond) * termsToSum1)
    
  }
}


CmpEMOptim<-function(x, theta, maxIt = 100, tolX = 1e-10, tolY = 1e-10){
  
  n <- length(x)
  it <- 0
  relChangeX <- tolX+1
  relChangeY <- tolY+1
  negloglik <- CmpnegloglikFunc(x, theta)
  
  while( relChangeX > tolX && relChangeY > tolY && it < maxIt){
    
    thetaOld <- theta
    negloglikOld <- negloglik
    
    tmpResult <- optim(thetaOld, function(par){CmpEStep(x, thetaOld, par)})
    
    theta <- tmpResult$par
    negloglik <- CmpnegloglikFunc(x, theta)
    
    relChangeX <- norm(theta-thetaOld,"2")/norm(thetaOld,"2")
    relChangeY <- abs(negloglik-negloglikOld)/abs(negloglikOld)
    
    it <- it + 1
  }
  
  if (!(relChangeX > tolX)) {stopcrit <- "theta stopped"}
  else if (!(relChangeY > tolY)) {stopcrit <- "negloglik stopped"}
  else stopcrit <- "Max iterations met"
  return(list(negloglik = negloglik, iterations= it, relChangeY = relChangeY, relChangeX = relChangeX, stopcrit = stopcrit,theta = theta))
}


CmpEMAn<-function(x, theta, maxIt = 100, tolX = 1e-10, tolY = 1e-10){
  
  n <- length(x)
  it <- 0
  relChangeX <- tolX+1
  relChangeY <- tolY+1
  negloglik <- CmpnegloglikFunc(x, theta)
  
  while( relChangeX > tolX && relChangeY > tolY && it < maxIt){
    
    thetaOld<-theta
    negloglikOld <- negloglik
    
    theta <- CmpEMStep(x, theta)
    negloglik <- CmpnegloglikFunc(x, theta)
    
    relChangeX <- norm(theta-thetaOld,"2")/norm(thetaOld,"2")
    relChangeY <- abs(negloglik-negloglikOld)/abs(negloglikOld)
    it <- it + 1
  }
  
  if (!(relChangeX > tolX)) {stopcrit <- "theta stopped"}
  else if (!(relChangeY > tolY)) {stopcrit <- "negloglik stopped"}
  else stopcrit <- "Max iterations met"
  
  return(list(negloglik = negloglik, iterations= it, relChangeY = relChangeY, relChangeX = relChangeX, stopcrit = stopcrit ,theta = theta))
}


CmpEMStep<-function(x, theta){
  n <- length(x)
  MP0 <- CmpMembershipProb(x, 0, theta)
  MP1 <- CmpMembershipProb(x, 1, theta)
  SMP0 <- sum(MP0)
  SMP1 <- sum(MP1)
  
  theta[1] <- SMP1/n
  theta[2] <- sum(MP1*x)/SMP1
  theta[3] <- sum(MP1*(x-theta[2])^2)/SMP1
  theta[4] <- sum(MP0*x)/SMP0
  theta[5] <- sum(MP0*(x-theta[4])^2)/SMP0
  
  return(theta)
}

