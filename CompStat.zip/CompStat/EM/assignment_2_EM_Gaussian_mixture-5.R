source("sc_EM.r")
################################################
##### Expectation - Maximization Algorithm #####
################################################
## Run test on psi data
psi_data <- scan("psi.txt")
theta <- c(-1, 2, 1, 1, 0.2)
psi_fit <- EM(x = psi_data, theta = theta, stopCrit = "rel", tol = 1e-8, maxIter = 100)

## Plot histogram and combined density estimate
hist(psi_data, 30, prob = TRUE, xlim = c(-5,5),ylim = c(0,1), xlab = "psi", ylab = "density")
par(new = TRUE)
xfit <- seq(-5, 5, length = 200) 
yfit <- psi_fit$MLE[5]*dnorm(xfit, psi_fit$MLE[1], sqrt(psi_fit$MLE[3])) + (1 - psi_fit$MLE[5])*dnorm(xfit, psi_fit$MLE[2], sqrt(psi_fit$MLE[4]))
lines(xfit, yfit, col = "blue")

## Try with different initial values
thetaZeros <- matrix(
  c(
    0,0,1,1,0.5,
    -1,1,1,1,0.5,
    0,0,1,1,0.9,
    -1,1,1,1,0.1,
    theta
  )
  , ncol = 5, byrow = TRUE
)

nTests = nrow(thetaZeros)
testResults <- list()
for (i in 1:nTests){
  testResults = append(testResults, list(EM(x = psi_data, theta = as.vector(thetaZeros[i, ]), stopCrit = "rel", tol = 1e-8, maxIter = 100)))
}

testResults[1]
testResults[2]
testResults[3]
testResults[4]
testResults[5]

## Simulate from model
X <- GMMsim(psi_fit$MLE, length(psi_data))

## Simulate from different gaussian distribution
theta <- c(-1, 2, 1, 1, 0.2)
psi_fit2 <- EM(x = X, theta = theta, stopCrit = "rel", tol = 1e-2, maxIter = 100)
hist(X, 30, prob = TRUE, xlim = c(-5,5), xlab = "simulated data", ylab = "density")
par(new = TRUE)
xfit <- seq(-5, 5, length = 200) 
yfit <- psi_fit2$MLE[5]*dnorm(xfit, psi_fit2$MLE[1], sqrt(psi_fit2$MLE[3])) + (1 - psi_fit2$MLE[5])*dnorm(xfit, psi_fit2$MLE[2], sqrt(psi_fit2$MLE[4]))
lines(xfit, yfit, col = "red")

################################################
################ EM - Analytical ###############
################################################
theta <- c(-1, 2, 1, 1, 0.5)
psi_fit_analytical <- EM_Analytical(psi_data, theta, "rel", 1e-8 , 100)
mle_est <- psi_fit_analytical$MLE
hist(psi_data, prob = TRUE, 30, xlim = c(-5,5))
xfit <- seq(-5, 5, length = 200) 
yfit <- mle_est[5]*dnorm(xfit, mle_est[1], sqrt(mle_est[3])) + (1 - mle_est[5])*dnorm(xfit, mle_est[2], sqrt(mle_est[4]))
lines(xfit, yfit, col = "red")

# Add optim esimtated density
xfit <- seq(-5, 5, length = 200) 
yfit <- psi_fit$MLE[5]*dnorm(xfit, psi_fit$MLE[1], sqrt(psi_fit$MLE[3])) + (1 - psi_fit$MLE[5])*dnorm(xfit, psi_fit$MLE[2], sqrt(psi_fit$MLE[4]))
lines(xfit, yfit, col = "blue")

# Compare with optim version
mle_est
psi_fit$MLE

## Try with different initial values
thetaZeros <- matrix(
  c(
    0,0,1,1,0.5,
    -1,1,1,1,0.5,
    0,0,1,1,0.9,
    -1,1,1,1,0.1,
    theta
  )
  , ncol = 5, byrow = TRUE
)

nTests = nrow(thetaZeros)
testResults <- list()
for (i in 1:nTests){
  testResults = append(testResults, list(EM_Analytical(x = psi_data, theta = as.vector(thetaZeros[i, ]), stopCrit = "rel", tol = 1e-8, maxIter = 100)))
}

testResults[1]
testResults[2]
testResults[3]
testResults[4]
testResults[5]

################################################
########### Profiling & Benchmarking ###########
################################################
install.packages("Rprof")
require("microbenchmark");require("Rprof")
profvis(EM(x = psi_data, theta = theta, stopCrit = "rel", tol = 1e-8, maxIter = 100))
#profvis(EM_Analytical(psi_data, theta, "rel", 1e-8 , 100))

# Profile EM with Optim (most time spent by external calls within Optim)
Rprof()
  EM(x = psi_data, theta = theta, stopCrit = "rel", tol = 1e-8, maxIter = 100)
Rprof(NULL)
summaryRprof()

# Profile analytical EM
Rprof()
  EM_Analytical(psi_data, theta, "rel", 1e-8 , 100)
Rprof(NULL)
summaryRprof()


microbenchmark(EM(x = psi_data, theta = theta, stopCrit = "rel", tol = 1e-8, maxIter = 100), 
               EM_Analytical(psi_data, theta, "rel", 1e-8 , 100),
               times = 10)

## Benchmarking confirms that analytical solution is a lot faster

################################################
################ SEM-algorithm #################
################################################
## Estimate fisher information on psi data
FI_SEM <- FisherInf(Q, psi_data, psi_fit$MLE, method = "SEM")
psi_fit$MLE
diag(FI_SEM)
################################################
################ Profiling #####################
################################################
# Profile SEM algorithm (most time clearly spent by "jacobian" function)
Rprof()
  FisherInf(Q, psi_data, theta, method = "SEM")
Rprof(NULL)
summaryRprof()

