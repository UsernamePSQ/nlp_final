
cmpfile("CmpEMFUnctions.R")
loadcmp("CmpEMFUnctions.Rc")

profvis(EMAn(psi_data, theta, 500, 1e-20, 1e-20))

psi_data <- scan("psi.txt")
theta <- c(0.5, -1, 1, 2, 1)
psi_fit0 <- optim(theta, function(par) negloglikFunc(psi_data, par), method = "BFGS")
psi_fit0$par
psi_fit1 <- EMOptim(psi_data, theta, 200, 1e-20, 1e-20)
psi_fit1$theta
psi_fit2 <- EMBase(psi_data, theta, 200, 1e-20, 1e-20)
psi_fit2$theta
# Lader til at opst� en numerisk forskel - m� skyldes at de samme st�rrelser ikke udregnes 
#  og behandles flere gange, men at der rent faktisk anvendes pr�cis de samme st�rerlser
psi_fit3 <- EMRcpp(psi_data, theta, 200, 1e-20) 
psi_fit3$theta

diag(FisherInfo(psi_data, theta, 1))
#Test base vs optim: Results only - inklud�r ogs� hessian/iXINV/std.afv for estimater her
psi_data <- scan("psi.txt")
theta <- c(0.2, -1, 1, 2, 1)
psi_fit <- EMFuncOptim(psi_data, theta, 5)
psi_fit$Matrix
psi_fit2 <- EMBase(psi_data, theta, 20)
#Test base for different init - vis at de kan skifte
#Algorithm not very robust
resultMatrix <- matrix(NA, nrow=9, ncol = 6)
resultMatrix2 <- matrix(NA, nrow=9, ncol = 6)
colnames(resultMatrix) <- list("p", "mu1", "sigmasq1", "mu2", "sigmasq2", "negloglik")
colnames(resultMatrix2) <- list("p", "mu1", "sigmasq1", "mu2", "sigmasq2", "negloglik")
xPlotValues <- seq(min(psi_data),max(psi_data),by=0.1)
plottingValues <- matrix(NA, nrow=9, ncol=length(xPlotValues))
cols<-rainbow(9)
tmp<-rep(NA,9)
tmp2<-rep(NA,9)
par(mfrow=c(1,2))
hist(psi_data, prob = T, ylim=c(0,0.7))
for(i in (1:9)){
  theta <- c(0.5, -i, 1, 1, 1)
  #theta <- c(i/10, -1+(i-1)/4, 1, 1, 1)
  resultMatrix[i,-6] <- EMBase(psi_data, theta, 100, 1e-20)$theta
  resultMatrix[i,6]<-EMBase(psi_data, theta, 100, 1e-20)$negloglik
  plottingValues[i,] <- densityPlotValues(xPlotValues, resultMatrix[i,-6])
  lines(xPlotValues, plottingValues[i,], col = cols[i], lwd=2)
}


hist(psi_data, breaks = 10,prob = T, ylim=c(0,0.8))
for(i in (1:9)){
  theta <- c(i/10, -1, 1, 1, 1)
  #theta <- c(i/10, -1+(i-1)/4, 1, 1, 1)
  resultMatrix2[i,-6] <- EMOptim(psi_data, theta, 100 ,1e-20)$theta
  resultMatrix2[i,6]<-EMOptim(psi_data, theta, 20)$negloglik
  plottingValues[i,] <- densityPlotValues(xPlotValues, resultMatrix2[i,-6])
  lines(xPlotValues, plottingValues[i,], col = cols[i], lwd=2)
}

par(mfrow=c(1,1))


for(i in (1:9)){
  #theta <- c(-1, 2, 1, 1, i/10)
  theta <- c(i/10, -1, 1, 1, 1)
  print(EMOptim(psi_data, theta, 500 ,1e-20)$theta)
}

#Test base for simuleret dataset - evt ogs� for diff init: test for meget h�je og meget flade - introduc�r stopping crit som er theta �ndres n�sten ikke - vis hvilket stop crit er anvendes- forh�bentligt kan konstrueres eksempler p� begge stopping crit (ikke maxIt)
n <- 1000

thetas<-c(0.1, -1, 0.5, 1, 0.5, 
  0.7, 1, 0.5, 4, 0.5, 
  0.7, -3, 0.5, -5, 0.5,
  0.4, 1, 0.5, -1, 0.5,
  0.5, -2, 0.2, 2, 0.2,
  0.5, -1, 1, 1, 1)

thetaMatrix<-matrix(thetas, nrow = 6, ncol = 5, byrow=T)
resultTheta<-matrix(NA, nrow = 6, ncol = 5, byrow=T)
resultOptimTheta<-matrix(NA, nrow = 6, ncol = 5, byrow=T)
simsets<-matrix(NA, nrow = 6, ncol = n)
starttheta<-c(0.5,-1,1,1,1)
par(mfrow=c(2,3))
for( i in (1:6)){
simsets[i,]<-SimFunc(n,thetaMatrix[i,])
results<-EMBase(simsets[i,], starttheta, 2000, 1e-8)
resultsOptim<-EMOptim(simsets[i,], starttheta, 2000, 1e-8)
resultTheta[i,]<-results$theta
resultOptimTheta[i,]<-resultsOptim$theta
hist(simsets[i,], breaks = 30,prob = T, sub = paste("Optim iterations:", resultsOptim$iterations),xlab=paste("Base iterations:", results$iterations),main="")
xPlotValues <- seq(min(simsets[i,]),max(simsets[i,]),by=0.1)
lines(xPlotValues, densityPlotValues(xPlotValues, results$theta), lwd=2)
lines(xPlotValues, densityPlotValues(xPlotValues, resultsOptim$theta), lwd=2, col="blue")
}


theta<-c(0.4, -1, 1, 1, 1)
result<-EMBase(simsets[5,], theta, 500, tolY = 1e-13, tolX = 1e-13)

xPlotValues <- seq(min(simsets[5,]),max(simsets[5,]),by=0.1)
lines(xPlotValues, densityPlotValues(xPlotValues, result$theta))

#### FISHER
psi_data <- scan("psi.txt")
theta <- c(0.5, -1, 1, 2, 1)
psi_fit <- EMOptim(psi_data, theta, 100, 1e-20)
solve(psi_fit$iYhat)
psi_fit2 <- EMBase(psi_data, theta, 100, 1e-20)
solve(psi_fit$iYhat)
psi_fit3 <- EMAnStats(psi_data, theta, 100, 1e-10, 1e-10)
psi_fit3
FisherInfo(psi_data, psi_fit2$theta, method = 1)
FisherInfo(psi_data, psi_fit2$theta, method = 2)
##


#Test base vs Rcpp vs Nice tid - evt profil undervejs som dokumentation for tidsovervejelser
