negloglikFunc<-function(x, theta){
  if(theta[1]<0 || theta[1]>1 || theta[3]<=0 || theta[5]<=0){return(Inf)}
  -sum(log(theta[1] * dnorm(x, theta[2], sqrt(theta[3])) + (1-theta[1]) * dnorm(x, theta[4], sqrt(theta[5]))))
}

MembershipProb<-function(x, z, theta){

  dnorm0 <- dnorm(x, theta[4], sqrt(theta[5]))
  dnorm1 <- dnorm(x, theta[2], sqrt(theta[3]))
  
  
  ((z==1) * theta[1] * dnorm1 + (z==0) * (1-theta[1]) * dnorm0)/
           (theta[1] * dnorm1 +          (1-theta[1]) * dnorm0)
  
}

EStep<-function(x, thetaCond, theta){
  if(theta[1]<0 || theta[1]>1 || theta[3]<=0 || theta[5]<=0){return(Inf)}
  else{
    termsToSum0 <- log(1 - theta[1]) - 0.5 * (log(2*pi) + log(theta[5]) + (x-theta[4])^2/theta[5])
    termsToSum1 <- log(theta[1])     - 0.5 * (log(2*pi) + log(theta[3]) + (x-theta[2])^2/theta[3])
  
    -sum(MembershipProb(x, 0, thetaCond) * termsToSum0 +
         MembershipProb(x, 1, thetaCond) * termsToSum1)
      
    }
}

EMOptim<-function(x, theta, maxIt = 100, tolX = 1e-10, tolY = 1e-10){

  n <- length(x)
  it <- 0
  relChangeX <- tolX+1
  relChangeY <- tolY+1
  negloglik <- negloglikFunc(x, theta)
  
  while( relChangeX > tolX && relChangeY > tolY && it < maxIt){

    thetaOld <- theta
    negloglikOld <- negloglik
    
    tmpResult <- optim(thetaOld, function(par){EStep(x, thetaOld, par)})

    theta <- tmpResult$par
    negloglik <- negloglikFunc(x, theta)
    
    relChangeX <- norm(theta-thetaOld,"2")/norm(thetaOld,"2")
    relChangeY <- abs(negloglik-negloglikOld)/abs(negloglikOld)
    
    it <- it + 1
  }
  
  if (!(relChangeX > tolX)) {stopcrit <- "theta stopped"}
  else if (!(relChangeY > tolY)) {stopcrit <- "negloglik stopped"}
  else stopcrit <- "Max iterations met"
  return(list(negloglik = negloglik, iterations= it, relChangeY = relChangeY, relChangeX = relChangeX, stopcrit = stopcrit,theta = theta))
}


EMAn<-function(x, theta, maxIt = 100, tolX = 1e-10, tolY = 1e-10){
  
  n <- length(x)
  it <- 0
  relChangeX <- tolX+1
  relChangeY <- tolY+1
  negloglik <- negloglikFunc(x, theta)
  
  while( relChangeX > tolX && relChangeY > tolY && it < maxIt){
    
    thetaOld<-theta
    negloglikOld <- negloglik
    
    theta <- EMStep(x, theta)
    negloglik <- negloglikFunc(x, theta)
    
    relChangeX <- norm(theta-thetaOld,"2")/norm(thetaOld,"2")
    relChangeY <- abs(negloglik-negloglikOld)/abs(negloglikOld)
    it <- it + 1
  }
  
  if (!(relChangeX > tolX)) {stopcrit <- "theta stopped"}
  else if (!(relChangeY > tolY)) {stopcrit <- "negloglik stopped"}
  else stopcrit <- "Max iterations met"
  
  return(list(negloglik = negloglik, iterations= it, relChangeY = relChangeY, relChangeX = relChangeX, stopcrit = stopcrit ,theta = theta))
}


EMStep<-function(x, theta){
  n <- length(x)
  MP0 <- MembershipProb(x, 0, theta)
  MP1 <- MembershipProb(x, 1, theta)
  SMP0 <- sum(MP0)
  SMP1 <- sum(MP1)
  
  theta[1] <- SMP1/n
  theta[2] <- sum(MP1*x)/SMP1
  theta[3] <- sum(MP1*(x-theta[2])^2)/SMP1
  theta[4] <- sum(MP0*x)/SMP0
  theta[5] <- sum(MP0*(x-theta[4])^2)/SMP0
  
  return(theta)
}

SimFunc<-function(n, theta){
  Y1 <- rnorm(n, mean= theta[2], sd = sqrt(theta[3]))
  Y2 <- rnorm(n, mean= theta[4], sd = sqrt(theta[5]))
  Z <- runif(n)
  return((Z<=theta[1])*Y1+(Z>theta[1])*Y2)
}

FisherInfo<-function(x, theta, method=1){
  n <- length(theta)
  iY <- hessian(func = function(param) EStep(x, theta, param), theta)
  DPsi <- jacobian(function(param) EMStep(x, param), theta)
  iYinv <- solve(iY)
       if (method == 1){iYinv %*% solve((diag(1, n) - t(DPsi)))}
  else if (method == 2){iYinv + iYinv %*% t(solve(diag(1, n) - DPsi, DPsi))}
  else warning(paste("method unsupported:", method))
}

densityPlotValues<-function(x, theta){
  theta[1] * dnorm(x, theta[2], sqrt(theta[3])) + (1-theta[1]) * dnorm(x, theta[4], sqrt(theta[5]))
}

#cppFunction('NumericVector test(NumericVector')


cppFunction('List EMRcpp(NumericVector x, NumericVector theta, double maxIt = 100, double tolY = 1e-10, double tolX = 1e-10) {
  int n  = x.size();
  int it = 0;
  double relChangeY = tolY+1;
  double relChangeX = tolX+1;

  double negloglikOld;
  NumericMatrix thetaMatrix(theta.size(), maxIt);
            
  NumericVector dnorm0 = dnorm(x, theta[3], sqrt(theta[4]));
  NumericVector dnorm1 = dnorm(x, theta[1], sqrt(theta[2]));

  NumericVector tmp0;
  NumericVector tmp1;
  NumericVector MP0;
  NumericVector MP1;
  double SMP0;
  double SMP1;
            
  double negloglik = -sum(log(theta[0] * dnorm1 + (1-theta[0]) * dnorm0));
            
  while((relChangeY > tolY) && (relChangeX > tolX) &&  (it < maxIt)) {
            
     negloglikOld = negloglik;
     thetaMatrix(_, it) = theta;

     tmp0 = (1-theta[0]) * dnorm0;
     tmp1 = theta[0] * dnorm1;
     MP0 = tmp0 / (tmp0 + tmp1);
     MP1 = tmp1 / (tmp0 + tmp1);
     SMP0 = sum(MP0);
     SMP1 = sum(MP1);  

           
     theta[0] = SMP1/n;
     theta[1] = sum(MP1 * x) / SMP1;
     theta[2] = sum(MP1 * pow(x-theta[1],2)) / SMP1;
     theta[3] = sum(MP0 * x) / SMP0;
     theta[4] = sum(MP0 * pow(x-theta[3],2)) / SMP0;
            
     dnorm0 = dnorm(x, theta[3], sqrt(theta[4]));
     dnorm1 = dnorm(x, theta[1], sqrt(theta[2]));
            
     negloglik = -sum(log(theta[0] * dnorm1 + (1-theta[0]) * dnorm0));


     relChangeY = std::abs(negloglik-negloglikOld)/std::abs(negloglikOld);
     relChangeX = sqrt(sum(pow(theta-thetaMatrix(_, it),2)))/sqrt(sum(pow(thetaMatrix(_, it),2)));
  
     it += 1;
    }
List ret; 
if (relChangeY <= tolY) {ret["stopcrit"] = "negloglik stopped";}
else {ret["stopcrit"] = "Max iterations met";}
ret["negloglik"] = negloglik; ret["iterations"] = it; ret["relChangeY"] = relChangeY; ret["relChangeX"] = relChangeX; 
ret["theta"] = thetaMatrix(_, it-1); 
return ret;
}')


# EMBase2<-function(x, theta, maxIt = 100, tolY = 1e-10, tolX = 1e-10){
#   
#   n <- length(x)
#   it <- 0
#   relChangeY <- tolY+1
#   relChangeX <- tolX+1
#   negloglik <- EStep(x, theta)
#   
#   while( relChangeY>tolY && relChangeX>tolX && it < maxIt){
#     negloglikOld<-negloglik
#     thetaOld<-theta
#     
#     MP0 <- MembershipProb(x, 0, theta)
#     MP1 <- MembershipProb(x, 1, theta)
#     SMP0 <- sum(MP0)
#     SMP1 <- sum(MP1)
#     
#     theta[1] <- SMP1/n
#     theta[2] <- sum(MP1*x)/SMP1
#     theta[3] <- sum(MP1*(x-theta[2])^2)/SMP1
#     theta[4] <- sum(MP0*x)/SMP0
#     theta[5] <- sum(MP0*(x-theta[4])^2)/SMP0
#     
#     negloglik <- EStep(x, theta)
#     relChangeY  <- abs(negloglik-negloglikOld)/abs(negloglikOld)
#     relChangeX  <- norm(theta-thetaOld, "2")/norm(thetaOld,"2")
#     it <- it + 1
#   }
#   
#   return(list(negloglik = negloglik, iterations= it, relChangeY = relChangeY, relChangeX = relChangeX ,theta = theta))
# }


# EMAnStats<-function(x, theta, maxIt = 100, tolY = 1e-10, tolX = NULL){
#   n <- length(x)
#   it <- 0
#   tolOk=T
#   negloglik <- EStep(x, theta)
#   nCols<-length(c(it,theta,negloglik,tolY,tolX))
#   colnames<-c("it", "p", "mu1", "sigmasq1", "mu2", "sigmasq2", "negloglik", "relChangesY", "relChangesX")
#   resultMatrix<-matrix(NA, nrow = maxIt, ncol = nCols)
#   colnames(resultMatrix) <- colnames[1:nCols]
#   thetaCols<-c(2:6)
#   while( tolOk && it < maxIt){
#     resultMatrix[it+1,"it"]        <- it
#     resultMatrix[it+1,"negloglik"] <- negloglik
#     resultMatrix[it+1, thetaCols]     <- theta
#     
#     theta     <- EMStep(x, theta)
#     negloglik <- EStep(x, theta)
#     
#     stopCrit <- stopCritFunc(resultMatrix, it, negloglik, theta, tolY, tolX)
#     resultMatrix[it+2, match("relChangesY", colnames(resultMatrix)):nCols] <- stopCrit$relChanges
#     tolOk <- (min(stopCrit$tolOk) == 1)
#     it <- it + 1
#   }
#   resultMatrix[it+1,"it"]        <- it
#   resultMatrix[it+1,"negloglik"] <- negloglik
#   resultMatrix[it+1, thetaCols]     <- theta
#   
#   
#   resultMatrix <- subset(resultMatrix, !is.na(resultMatrix[,"relChangesY"]))
#   stopCritMet <- if(it == maxIt){"max iterations reached"}
#   else if (!stopCrit$tolOk[1]){"Relative changes in Y below tolerance"}
#   else {"Relative changes in X below tolerance"}
#   return(list(stats = resultMatrix, stopCritMet = paste("Stopping criterion met:", stopCritMet) ))
# }
# 
# stopCritFunc<-function(resultMatrix, it, negloglik, theta, tolY, tolX){
#   relChangeX <- NULL
#   tolXOk     <- NULL
#   
#   relChangeY  <- abs(negloglik-resultMatrix[it+1,"negloglik"])/abs(resultMatrix[it+1,"negloglik"])
#   tolYOk<-(relChangeY > tolY)
#   if(!is.null(tolX)){
#     relChangeX  <- norm(theta-resultMatrix[it+1,c(2:6)], "2")/norm(resultMatrix[it+1,c(2:6)],"2")
#     tolXOk<-(relChangeX > tolX)
#   }
#   return(list(tolOk = c(tolYOk, tolXOk), relChanges = c(relChangeY, relChangeX)))
# }

# InCompleteDensity<-function(x, theta){
#   theta[1] * dnorm(x, theta[2], sqrt(theta[3])) + (1-theta[1]) * dnorm(x, theta[4], sqrt(theta[5]))
# }
# 
# CompleteDensity<-function(x, z, theta){
#   #Note: Given x obs and theta, only the indicator is random
#   (z==1) * theta[1] * dnorm(x, theta[2], sqrt(theta[3])) + (z==0) * (1-theta[1]) * dnorm(x, theta[4], sqrt(theta[5]))
# }
