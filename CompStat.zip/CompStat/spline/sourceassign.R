Omegafunc<-function(x,method="default",nPoints=NULL){
  unix<-unique(x)
  if (method=="OR"){
    omegaTmp<-matrix(data=0,nrow=(length(unix)+2),ncol=(length(unix)+2))
    pointsTmp<-seq(min(unix),max(unix),length.out = nPoints)
    xdist<-.subset2(pointsTmp,2)-.subset2(pointsTmp,1)
    splineEvaluations<-splineDesign(x,pointsTmp,ord=4,derivs = rep(2,length(pointsTmp)))
    for(k in (1:length(pointsTmp))){
      omegaTmp<-omegaTmp+outer(splineEvaluations[k,],splineEvaluations[k,],"*")
    }
    omegaTmp<-omegaTmp*xdist
  } else  {
    omegaTmp<-bsplinepen(create.bspline.basis(range(c(min(unix),max(unix))), breaks = unix))
  }
  omegaTmp
}