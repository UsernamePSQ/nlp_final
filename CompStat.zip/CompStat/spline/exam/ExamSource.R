PhiMatrix<-function(x){
  x2 <- c(rep(.subset2(x,1),3),x,rep(.subset2(x,length(x)),3))
  splineDesign(knots = x2, x = x, outer.ok = F, sparse = F)
}

OmegaMatrix<-function(x){
  bsplinepen(create.bspline.basis(range(c(min(x),max(x))), breaks = x), returnMatrix = F)
}

splineFit.simple<-function(z){
  S <- z$phi%*%solve((t(z$phi)%*%z$phi+z$lambda*z$omega))%*%t(z$phi)
  shat <- S%*%z$y
  CVRSS<-sum(  ( (z$y-z$shat)/(1-diag(S)) )^2 )
  cvCrit<-z$CVRSS/length(z$y)
  return(list(shat = shat, lambda = z$lambda, CVRSS = CVRSS, cvCrit = cvCrit))
}

splineFit<-function(z){
  UseMethod("splineFit")
}

splineFit.sapply<-function(z){
  lambda <- seq(z$lower, z$upper, by = z$by)
  z$tmp <- t(z$phi) %*% z$phi
  CvrssMatrix <- sapply(lambda, function(l) {CvrssFunc(l, z)})
  lambda<-lambda[CvrssMatrix == min(CvrssMatrix)]
  shat<-z$phi%*%solve((z$tmp+lambda*z$omega))%*%t(z$phi)%*%z$y
  CVRSS<-min(CvrssMatrix)
  cvCrit<-CVRSS/length(z$y)
  return(list(shat = shat, lambda = lambda, CVRSS = CVRSS, cvCrit = cvCrit))
}

CvrssFunc <-function(l, z){
  S <- z$phi %*% solve((z$tmp + l * z$omega)) %*% t(z$phi)
  shat <- S %*% z$y
  return(sum(((z$y - shat) / (1 - diag(S)))^2 ))
}

splineFit.optim<-function(z){
  z$tmp<-t(z$phi) %*% z$phi
  optimResult<-optim(par = (z$upper+z$lower)/2, function(l) {CvrssFunc(l,z)}, method = "Brent", lower = z$lower, upper = z$upper)
  lambda<-optimResult$par
  shat<-z$phi%*%solve((z$tmp+lambda*z$omega))%*%t(z$phi)%*%z$y
  CVRSS<-optimResult$value
  cvCrit<-CVRSS/length(z$y)
  return(list(shat = shat, lambda = lambda, CVRSS = CVRSS, cvCrit = cvCrit))
}


mySpline<-function(z){
  z$phi <- PhiMatrix(z$x)
  z$omega <- OmegaMatrix(z$x)
  z$resultList <- splineFit(z)
  structure(z, class = c("splineResult", class(z)))
}

lines.splineResult<-function(z,...){
  x<-z$x
  shat<-z$resultList$shat
  lines.default(x,shat,...)
}

#Make func to error handle this:
#x, y,lower=1e-10,upper=1,by=1e-2, lambda(optional)

initSpline<-function(x, y, lower = NULL, upper = NULL, by = NULL, lambda = NULL, method = NULL ){
  y <- y[order(x)]
  x <- sort(x)
  if( (!(is.null(lambda))) && !(class=="simple")){
    warning("Both a lambda and a class used to calculate lambda was specified. Class changed to: simple")
    method <- "simple"
  }
  structure(list(x = x, y = y, lower = lower, upper = upper, by = by, lambda = lambda), class = method)
}
  
#### Loess
myLoessSpan <- function(x, y, maxspan=0.5, minspan = 0.01, step=0.01, ...){
  #Possible warnings: degree of freedom and memory (supposedly results in a more rough estimate)
  spanVar <- seq(from=minspan, to=maxspan, by=step)
  tmp     <- rep(NA, length(spanVar))
  splineReference <- smooth.spline(x, y, all.knots = T, cv = T)
  for (i in seq(spanVar)){
    tmp[[i]] <- sum(abs(loess.smooth(x, y, spanVar[i], evaluation=length(x))$y-splineReference$y))
  }
  bestSpan <- spanVar[tmp == min(tmp)]
  bestSpan
}


myLoessSpan2 <- function(x,y,maxspan=0.5, minspan = 0.01, step=0.01, ...){
  spanVar <- seq(from=minspan, to=maxspan, by=step)
  tmp     <- list()
  splineReference <- smooth.spline(x, y, all.knots = T, cv = T)
  for (i in seq(spanVar)){
    tmp[[i]] <- tryCatch(sum(abs(loess.smooth(x,y,spanVar[i], evaluation=length(x))$y-splineReference$y)), 
                         warning = function(c) {msg <- conditionMessage(c)
                         invisible(structure(msg, class = "try-error"))})
  }
  spanVar <- as.vector(spanVar[!sapply(tmp, is.error)], mode = "numeric")
  resultSuccess <- as.vector(tmp[!sapply(tmp, is.error)], mode = "numeric")
  reultFails <-  as.vector(tmp[sapply(tmp, is.error)], mode = "character")
  bestSpan <- spanVar[resultSuccess == min(resultSuccess)]
  return(list(bestSpan = bestSpan, resultSuccess = resultSuccess, reultFails = reultFails))
}


is.error <- function(x) inherits(x, "try-error")

############ For the microbenchmarks

##Sparse
PhiMatrixSparse<-function(x){
  x2 <- c(rep(.subset2(x,1),3),x,rep(.subset2(x,length(x)),3))
  splineDesign(knots = x2, x = x, outer.ok = F, sparse = T)
}

OmegaMatrixSparse<-function(x){
  Matrix(bsplinepen(create.bspline.basis(range(c(min(x),max(x))), breaks = x), returnMatrix = T), sparse=T)
}

mySplineSparse<-function(z){
  z$phi <- PhiMatrixSparse(z$x)
  z$omega <- OmegaMatrixSparse(z$x)
  z$resultList <- splineFit(z)
  structure(z, class = c("splineResult", class(z)))
}

## Cmp and sparse
PhiMatrixSparseCmp<-cmpfun(PhiMatrixSparse)
OmegaMatrixSparseCmp<-cmpfun(OmegaMatrixSparse)
CvrssFuncCmp<-cmpfun(CvrssFunc)
splineFitCmp<-function(z){
  UseMethod("splineFitCmp")
}
splineFitCmp<-cmpfun(splineFitCmp)

splineFitCmp.optim<-function(z){
  z$tmp<-t(z$phi) %*% z$phi
  optimResult<-optim(par = (z$upper+z$lower)/2, function(l) {CvrssFuncCmp(l,z)}, method = "Brent", lower = z$lower, upper = z$upper)
  lambda<-optimResult$par
  shat<-z$phi%*%solve((z$tmp+lambda*z$omega))%*%t(z$phi)%*%z$y
  CVRSS<-optimResult$value
  cvCrit<-CVRSS/length(z$y)
  return(list(shat = shat, lambda = lambda, CVRSS = CVRSS, cvCrit = cvCrit))
}
splineFitCmp.optim <- cmpfun(splineFitCmp.optim)

splineFitCmp.sapply<-function(z){
  lambda <- seq(z$lower, z$upper, by = z$by)
  z$tmp <- t(z$phi) %*% z$phi
  CvrssMatrix <- sapply(lambda, function(l) {CvrssFuncCmp(l, z)})
  lambda<-lambda[CvrssMatrix == min(CvrssMatrix)]
  shat<-z$phi%*%solve((z$tmp+lambda*z$omega))%*%t(z$phi)%*%z$y
  CVRSS<-min(CvrssMatrix)
  cvCrit<-CVRSS/length(z$y)
  return(list(shat = shat, lambda = lambda, CVRSS = CVRSS, cvCrit = cvCrit))
}
splineFitCmp.sapply <- cmpfun(splineFitCmp.sapply)

mySplineSparseCmp<-function(z){
  z$phi <- PhiMatrixSparseCmp(z$x)
  z$omega <- OmegaMatrixSparseCmp(z$x)
  z$resultList <- splineFitCmp(z)
  structure(z, class = c("splineResult", class(z)))
}
mySplineSparseCmp<-cmpfun(mySplineSparseCmp)

# Cmp no sparse
PhiMatrixCmpNosparse<-cmpfun(PhiMatrix)
OmegaMatrixCmpNoSparse<-cmpfun(OmegaMatrix)

mySplineCmpNoSparse<-function(z){
  z$phi <- PhiMatrixCmpNosparse(z$x)
  z$omega <- OmegaMatrixCmpNoSparse(z$x)
  z$resultList <- splineFitCmp(z)
  structure(z, class = c("splineResult", class(z)))
}
mySplineCmpNoSparse<-cmpfun(mySplineCmpNoSparse)

## Rcpp
mySplineRcpp<-function(z){
  z$phi <- PhiMatrix(z$x)
  z$omega <- OmegaMatrix(z$x)
  z$resultList <- splineFitRcpp(z)
  structure(z, class = c("splineResult", class(z)))
}
mySplineRcpp<-cmpfun(mySplineRcpp)


splineFitRcpp<-function(z){
  UseMethod("splineFitRcpp")
}
splineFitRcpp<-cmpfun(splineFitRcpp)

splineFitRcpp.optim<-function(z){
  z$tmp<-t(z$phi) %*% z$phi
  optimResult<-optim(par = (z$upper+z$lower)/2, function(l) {CvrssRcpp(l, z$phi, z$omega, z$y)}, method = "Brent", lower = z$lower, upper = z$upper)
  lambda<-optimResult$par
  shat<-z$phi%*%solve((z$tmp+lambda*z$omega))%*%t(z$phi)%*%z$y
  CVRSS<-optimResult$value
  cvCrit<-CVRSS/length(z$y)
  return(list(shat = shat, lambda = lambda, CVRSS = CVRSS, cvCrit = cvCrit))
}


splineFitRcpp.sapply<-function(z){
  lambda <- seq(z$lower, z$upper, by = z$by)
  z$tmp <- t(z$phi) %*% z$phi
  CvrssMatrix <- sapply(lambda, function(l) {CvrssRcpp(l, z$phi, z$omega, z$y)})
  lambda<-lambda[CvrssMatrix == min(CvrssMatrix)]
  shat<-z$phi%*%solve((z$tmp+lambda*z$omega))%*%t(z$phi)%*%z$y
  CVRSS<-min(CvrssMatrix)
  cvCrit<-CVRSS/length(z$y)
  return(list(shat = shat, lambda = lambda, CVRSS = CVRSS, cvCrit = cvCrit))
}

cppFunction(depends = "RcppArmadillo",
            'double CvrssRcpp(double lambda, arma::mat phi, arma::mat omega, arma::vec y){
            arma::mat S = phi * inv(phi.t()*phi+lambda*omega)*phi.t();
            arma::vec shat = S*y;
            arma::vec CVRSS = pow(y-shat,2) / pow(1-S.diag(),2);
            return sum(CVRSS);
            }
            ')

##Rcpp and cmp
mySplineRcppCmp<-function(z){
  z$phi <- PhiMatrix(z$x)
z$omega <- OmegaMatrix(z$x)
z$resultList <- splineFitRcppCmp(z)
structure(z, class = c("splineResult", class(z)))
}
mySplineRcppCmp<-cmpfun(mySplineRcppCmp)


splineFitRcppCmp<-function(z){
  UseMethod("splineFitRcppCmp")
}
splineFitRcppCmp<-cmpfun(splineFitRcppCmp)

splineFitRcppCmp.optim<-function(z){
  z$tmp<-t(z$phi) %*% z$phi
  optimResult<-optim(par = (z$upper+z$lower)/2, function(l) {CvrssRcpp(l, z$phi, z$omega, z$y)}, method = "Brent", lower = z$lower, upper = z$upper)
  lambda<-optimResult$par
  shat<-z$phi%*%solve((z$tmp+lambda*z$omega))%*%t(z$phi)%*%z$y
  CVRSS<-optimResult$value
  cvCrit<-CVRSS/length(z$y)
  return(list(shat = shat, lambda = lambda, CVRSS = CVRSS, cvCrit = cvCrit))
}
splineFitRcppCmp.optim<-cmpfun(splineFitRcppCmp.optim)

splineFitRcppCmp.sapply<-function(z){
  lambda <- seq(z$lower, z$upper, by = z$by)
  z$tmp <- t(z$phi) %*% z$phi
  CvrssMatrix <- sapply(lambda, function(l) {CvrssRcpp(l, z$phi, z$omega, z$y)})
  lambda<-lambda[CvrssMatrix == min(CvrssMatrix)]
  shat<-z$phi%*%solve((z$tmp+lambda*z$omega))%*%t(z$phi)%*%z$y
  CVRSS<-min(CvrssMatrix)
  cvCrit<-CVRSS/length(z$y)
  return(list(shat = shat, lambda = lambda, CVRSS = CVRSS, cvCrit = cvCrit))
}
splineFitRcppCmp.sapply<-cmpfun(splineFitRcppCmp.sapply)
