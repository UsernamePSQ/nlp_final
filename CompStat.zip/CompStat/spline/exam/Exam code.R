library('splines')
library('Matrix')
library('fda')
library('microbenchmark')
library('ggplot2')
library('profvis')
library('Rcpp')
library("compiler")

### Code used in microbenchmark
# initlist<-list(x = dataInit$X, y = dataInit$Y, lower=1e-10, upper=1, by=1e-2)
# splineSapply<-initSpline(initlist, "sapply")
# splineOptim<-initSpline(initlist, "optim")
# sapplyBase<-mySpline(splineSapply)
# sapplySparse<-mySplineSparse(splineSapply)
# sapplyCmp<-mySplineSparseCmp(splineSapply)
# optimBase<-mySpline(splineOptim)
# optimSparse<-mySplineSparse(splineOptim)
# optimCmp<-mySplineSparseCmp(splineOptim)
# smoothSpline <- smooth.spline(dataInit$X,dataInit$Y, all.knots = T,cv = T)



#Load data and run function
dataInit <- read.table("easysmooth.dat",header=T)
initlist<-list(x = dataInit$X, y = dataInit$Y, lower=1e-10, upper=1, by=1e-2)
splineObj<-initSpline(x = dataInit$X, y = dataInit$Y, lower=1e-10, upper=1, by=1e-2, method = "sapply")
base<-mySpline(splineObj)
plot(dataInit)
lines(base, col="black", lwd = 3)
smoothSpline <- smooth.spline(dataInit$X,dataInit$Y, all.knots =T,cv=T)
lines(smoothSpline,col="red", lwd = 2)

####Basic functionallity: Do we hit smooth.spline? Does it work in general?
#Hitting smooth.spline:
# Takes long time
par(mfrow=c(1,2))
plot(dataInit$X,base$resultList$shat-smoothSpline$y,type="l")
bettersearchlist<-splineObj
bettersearchlist$upper<-0.1
bettersearchlist$by<-1e-5
betterSearch<-mySpline(bettersearchlist)
plot(dataInit$X,betterSearch$resultList$shat-smoothSpline$y,type="l")
optimList<-splineObj
class(optimList)<-"optim"
optimfit<-mySpline(optimList)
plot(dataInit$X,(optimfit$resultList$shat-smoothSpline$y),type="l")
#Other stats:
#No CVRSS from smoothSpline, but cv.Crit...
str(smoothSpline)
betterSearch$resultList$lambda;smoothSpline$lambda
betterSearch$resultList$cvCrit-smoothSpline$cv.crit


#Moving on to the the general case:
testSet1<-cbind(c(seq(0,4,length.out = 20),seq(4.1,8,length.out = 60)),c(rep(1,20),seq(4,12,length.out = 60)))
testSet2<-cbind(seq(0,10,length.out = 50),(sapply(seq(0,10,length.out = 50),function(x)40-8*x+1.5*x^2-0.1*x^3))+rnorm(50,mean=0,sd=2))
tmpSet<-cbind(seq(0,10,length.out = 50),(lapply(seq(0,10,length.out = 50),function(x) 40-8*x+1.5*x^2-0.1*x^3)))
par(mfrow=c(2,1))
plot(testSet2,xlab="",ylab="", main = "3. degree pol with noise")
lines(tmpSet,col=30)
testlist2<-splineObj
testlist2$x<-testSet2[,1]
testlist2$y<-testSet2[,2]
lines(testSet2[,1],mySpline(testlist2)$resultList$shat,col="blue")
lines(smooth.spline(testSet2[,1],testSet2[,2]),col="black")
testlist2$lambda<-1e-10
class(testlist2)<-"simple"
lines(testSet2[,1],mySpline(testlist2)$resultList$shat,col="red")
testlist2$lambda<-1e5
lines(testSet2[,1],mySpline(testlist2)$resultList$shat,col="green")
#Note how the default does not need to be close whatsoever
plot(testSet1,xlab="",ylab="",main = "Discontinous set")
testlist1<-splineObj
testlist1$x<-testSet1[,1]
testlist1$y<-testSet1[,2]
lines(testSet1[,1],mySpline(testlist1)$resultList$shat,col="blue")
lines(smooth.spline(testSet1[,1],testSet1[,2]),col="black")
testlist1$lambda<-1e-10
class(testlist1)<-"simple"
lines(testSet1[,1],mySpline(testlist1)$resultList$shat,col="red")
testlist1$lambda<-1e5
lines(testSet1[,1],mySpline(testlist1)$resultList$shat,col="green")
par(mfrow=c(1,1))

####Closer inspection: Finds lambda at first step - this is an issue
base2<-mySpline(testSet1[,1],testSet1[,2]);base2$lambda
#Slow - still not even close
#betterSearch2<-mySpline(testSet1[,1],testSet1[,2],upper=0.2,by=1e-5)
strangeDataSS<-smooth.spline(testSet1[,1],testSet1[,2])
plot(testSet1,xlab="",ylab="")
lines(betterSearch2,col="blue")
lines(strangeDataSS,col="black")
betterSearch2$cvCrit;strangeDataSS$cv.crit

####Timing different "by"
#Slow - 2nd takes 10 times as long as 1st
profvis(mySpline(splineObj))
splineObj2<-splineObj
splineObj2$by<-1e-3
profvis(mySpline(splineObj2))

####Can use sparse to win ~15%-20% set values in phi and omega to TRUE
microbenchmark(mySpline(splineObj),times = 20)

###Alternatives to default CVRSS minimizing process
initlist<-list(x = dataInit$X, y = dataInit$Y, lower=1e-10, upper=1, by=1e-2)
splineObj<-initSpline(initlist, "sapplyFit")
base<-mySpline(splineObj)
splineObjOptim<-initSpline(initlist, "optim")
baseOptim<-mySpline(splineObjOptim)
