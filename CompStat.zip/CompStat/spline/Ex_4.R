library("microbenchmark")
#Problem 4.1
x<-rnorm(2^13)
test<-microbenchmark(
  density(x[1:2^5],0.2),
  density(x[1:2^6],0.2),
  density(x[1:2^7],0.2),
  density(x[1:2^8],0.2),
  density(x[1:2^9],0.2),
  density(x[1:2^10],0.2),
  density(x[1:2^11],0.2),
  density(x[1:2^12],0.2),
  density(x[1:2^13],0.2)
)

#Doesn't work yet
# tmpBenchmark<-list()
# for (i in (2^5:2^13)){ (tmpBenchmark[i-2^5+1]<-microbenchmark(density(x[1:i],0.2)))}
# tmpBenchmark[[1]]
#Problem 4.2

#exp(-z^2/2)/sqrt(2*pi)
x<-rnorm(2^13)
KernDens<-function(x,h,n){
  L<-min(x)-(max(x)-min(x))
  U<-max(x)+(max(x)-min(x))
  points<-seq(L,U,(U-L)/n)
  finalValues<-vector(mode="numeric",length(points)) 
  scale<-1/length(x)
  for (j in seq_along(points)){
    tmp<-0  
    for (i in seq_along(x)){
      tmp<-tmp+dnorm(points[j],x[i],h)
    }
    finalValues[j]<-scale*tmp
  } 
  return(finalValues)
}
KernDens(x[1:2^5],0.2,512)
density(x[1:2^5],0.2)

max(KernDens(x[1:2^5],0.2,512))
summary(KernDens(x[1:2^5],0.2,512))

par(2,1)
plot(KernDens(x[1:2^5],0.2,512))
plot(density(x[1:2^5],0.2))
