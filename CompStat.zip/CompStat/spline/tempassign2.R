library(splines)
library(Matrix)
library(microbenchmark)
library(profvis)
library(fda)

mySpline <- function(x,y){
  x <- c(min(x),min(x),min(x),x,max(x),max(x),max(x))
  y <- c(rep(y[1],3),y,rep(y[length(y)],3))
  A <- splineDesign(knots = x, x = x, outer.ok = F, sparse = T)
  omega <- bsplinepen(create.bspline.basis(range(c(min(x),max(x))), breaks = unique(x)))
  lambda <- seq(0.001,10,length.out = 1000)
  CVRSS <- rep(NA, 1000)
  for (i in 1:1000){
    S <- A%*%solve((t(A)%*%A+lambda[i]*omega))%*%t(A)
    shat <- S%*%y
    CVRSS[i] <- sum(  ( (y-shat)/(1-diag(S)) )^2 )
  }
  S <- A%*%solve((t(A)%*%A+lambda[CVRSS == min(CVRSS)]*omega))%*%t(A)
  shat <- S%*%y
  shat
  lambda[CVRSS == min(CVRSS)]
}



mySpline(x,y)





















IntegrandFunction<-function(knots,x,i,j,outer){
  splineEvaluations<-splineDesign(knots,x,ord=4,derivs=2,outer.ok = outer)
  return(.subset2(splineEvaluations, i)[1]*.subset2(splineEvaluations, j)[1])
}
vIntegrandFunction<-Vectorize(IntegrandFunction,vectorize.args="x")

OmegaCalc<-function(knots,lowerlim,upperlim,outer=F){
omega<-matrix(data= NA, nrow= length(knots)-4, ncol = length(knots)-4)
for (i in (1:(length(knots)-4))){
  for (j in (i:(length(knots)-4))){
    omega[i,j]<- .subset2(integrate(function(x) vIntegrandFunction(knots,x,i,j,outer),lower=lowerlim,upper=upperlim),1)
  }
}
forceSymmetric(omega,"U")
}

testOmega<-OmegaCalc(1:10,4,7,F)

simple_tri
a<-simple_triplet_zero_matrix(nrow = 1000, ncol = 1000)
a<-a+matrix(1,nrow=1000,ncol=1000)


mySpline <- function(x,y, n=100,method="default",nPoints=NULL,lower=0,upper=1,l){
  x <- sort(x)
  y <- y[order(x)]
  x <- c(rep(.subset2(y,1),3),x,rep(.subset2(x,length(x)),3))
  y <- c(rep(.subset2(y,1),3),y,rep(.subset2(y,length(y)),3))
  A <- splineDesign(knots = x, x = x, outer.ok = F, sparse = T)
  omega <- Omegafunc(x,method,nPoints)
  if (!missing(l)){lambda<-l} else {
    lambda <- seq(lower,upper,length.out = n)
    CVRSS <- sapply(lambda, function(l){
      S <- A%*%solve((t(A)%*%A+l*omega))%*%t(A)
      shat <- S%*%y
      return(sum(  ( (y-shat)/(1-diag(S)) )^2 )) }  )
    lambda<-lambda[CVRSS == min(CVRSS)]
  }
  shat <- A%*%solve((t(A)%*%A+lambda*omega))%*%t(A)%*%y
  return(list(shat=shat,CVRSS=CVRSS))
}


# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
Omegafunc<-function(x,method="default",nPoints=NULL){
  unix<-unique(x)
  if (method=="OR"){
  omegaTmp<-matrix(data=0,nrow=(length(unix)+2),ncol=(length(unix)+2))
  pointsTmp<-seq(min(unix),max(unix),length.out = nPoints)
  xdist<-.subset2(pointsTmp,2)-.subset2(pointsTmp,1)
  splineEvaluations<-splineDesign(x,pointsTmp,ord=4,derivs = rep(2,length(pointsTmp)),sparse=sparse)
    for(k in (1:length(pointsTmp))){
      omegaTmp<-omegaTmp+outer(splineEvaluations[k,],splineEvaluations[k,],"*")
}
omegaTmp<-omegaTmp*xdist
} else  {
    omegaTmp<-bsplinepen(create.bspline.basis(range(c(min(unix),max(unix))), breaks = unix))
  }
omegaTmp
}

Omegafunc2<-function(x,method="default",nPoints=NULL){
  unix<-unique(x)
  if (method=="OR"){
    omegaTmp<-simple_triplet_zero_matrix(nrow=(length(unix)+2),ncol=(length(unix)+2))
    pointsTmp<-seq(min(unix),max(unix),length.out = nPoints)
    xdist<-.subset2(pointsTmp,2)-.subset2(pointsTmp,1)
    splineEvaluations<-splineDesign(x,pointsTmp,ord=4,derivs = rep(2,length(pointsTmp)),sparse = T)
    for(k in (1:length(pointsTmp))){
      omegaTmp<-omegaTmp+outer(splineEvaluations[k,],splineEvaluations[k,],"*")
    }
    omegaTmp<-omegaTmp*xdist
  } else  {
    omegaTmp<-bsplinepen(create.bspline.basis(range(c(min(unix),max(unix))), breaks = unix))
  }
  omegaTmp
}

a<-microbenchmark( Omegafunc(data1$X))

a<-Omegafunc1(data1$X,"OR",nPoints=30000)
b<-Omegafunc(data1$X)

test<-dataInit$X[c(1:10)]
identical(test,dataInit$X)
omegaTmp<-matrix(data=0, nrow=12,ncol=12)
pointsTmp<-c(seq(1,10,length.out = 30000))
xdist<-pointsTmp[10]-pointsTmp[9]
tmp<-splineDesign(c(1,1,1,1:10,10,10,10),pointsTmp,ord=4,derivs = rep(2,length(pointsTmp)))
#outer(tmp[1,],tmp[1,],"*")
for (k in (1:length(pointsTmp))){
  omegaTmp<-omegaTmp+outer(tmp[k,],tmp[k,],"*")
}
omegaTmp<-xdist*omegaTmp

for (i in (1:12)){
  for (j in (1:12)){
    for (k in (1:length(pointsTmp))){
      #omegaTmp[i,j]<-omegaTmp[i,j]+tmp[k,i]*tmp[k,j]*xdist
    }
  }
}
omegaTmp<-(forceSymmetric(omegaTmp,"U"))
omegaTmp



omegaTmp2<-bsplinepen(create.bspline.basis(range(c(min(1),max(10))), breaks = 1:10))
omegaTmp<-bsplinepen(create.bspline.basis(range(c(min(dataInit$X),max(dataInit$X))), breaks = dataInit$X))
omegaTmp<-bsplinepen(create.bspline.basis(range(c(min(dataInit$X),max(dataInit$X))), breaks = dataInit$X))
# omegaTmp<-array(data= NA, dim=c(196,196,10000))
# tmp<-splineDesign(data$X,seq(-3.402,2.902,length.out = 10000),ord=4,derivs = 2)
# for (k in (1:10000)){
#   for (i in (1:196)){
#     for (j in (1:196)){
#       omegaTmp[i,j,k]<-tmp[k,i]*tmp[k,j]
#       omegaTmp[,,k]<-as.array(forceSymmetric(omegaTmp[,,k],"U"))
#     }
#   }
# }
# omega<-apply(omegaTmp[,,-1],c(1,2),sum)*(seq(-3.402,2.902,length.out = 10000)[2]-seq(-3.402,2.902,length.out = 10000)[1])
