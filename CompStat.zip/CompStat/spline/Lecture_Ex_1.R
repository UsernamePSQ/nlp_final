getwd()
wd<-setwd("CSdatasets")
getwd()
data <- read.table("infrared.dat",header=T)
hist(log(data$F12),breaks=5);rug(log(data$F12));
F12<-data$F12
# Own idea, not polished:
# myBreaks<-function(x,h=5){
#   if((0<h&&h<length(x)&&h==round(h))==FALSE){return("error")}  else {
#   h<-round(h)
#   sortedData<-sort((unique(x)))
#   nBreaks<-floor(length(x)/h)+1
#   breakIndices<-c(1,((1:(nBreaks-2))*h)+1,length(x))
#   #breaks<-sortedData[breakIndices]
#   return(sortedData[breakIndices])
#   }
# }
#Official sol. 1
myBreaks <- function(x, h = 5) {
  x <- sort(x)
  h <- min(h, length(x) - 1)
  breaks <- xb <- x[1]
  k <- 1
  for(i in seq_along(x)[-1]) {
    if (k >= h & xb < x[i]) {
      xb <- x[i]
      breaks <- c(breaks, xb)
      k <- 1
    } else {
      k <- k + 1
    }
  }
  breaks[length(breaks)] <- x[length(x)]
  breaks
}
#Official sol. 2
myBreaks2 <- function(x, h = 5) {
  x <- sort(x)
  breaks <- x[seq(1, length(x), h)]
  if (length(breaks) > 1)
    breaks <- breaks[-length(breaks)]
  breaks <- c(breaks, x[length(x)])
  unique(breaks)
}
myHist <- function(h, ...){
  hist(log(F12), function(x) myBreaks(x, h), ...)
}
#Problem 2.1
environment(myHist)
environment(myHist)<-new.env()
environment(myHist)
assign("F12",F12,environment(myHist))
rm(F12)
myHist(h=5)
F12<-data$F12

#Problem 2.2
myHist2 <- function(x,h, ...){
  hist(log(x), function(y) myBreaks(y, h), ...)
}





funfac<-function(x){
  return(
    function(h, ...){    
    hist(log(x), function(y) myBreaks(y, h), ...)
    }
  )
}

testfunc<-funfac(F12)
testfunc(20)
environment(testfunc)
ls.str(environment(testfunc))

#Problem 2.3
tmp<-myHist(10,plot=FALSE)
class(tmp)
typeof(tmp)
str(tmp)
plot(tmp,col= "red")
plot
methods(plot)
getAnywhere(plot.histogram)
?rect


#Problem 3.1
#Problem 3.2
myHist <- function(h, ...){
  tempHist<-hist(log(F12), function(x) myBreaks(x, h), plot=FALSE, ...)
  class(tempHist)<-c("myHistogram","histogram")
  return(tempHist)
}
testhist<-myHist(10)
?cat
print.myHistogram<-function(x) {
  force(x)
  cat("Number of cells is", length(x$breaks)-1)
}
print(testhist)
plot(testhist)    


#Problem 3.3
methods(summary)

summary.myHistogram<-function(x){
    tmpDataframe<-data.frame(x$mids,x$count)
    return(tmpDataframe)
}
summary(testhist)
#Problem 3.4
# require(ggplot2)
# ggplot(hist(log(F12,myBreaks(F12,10))))
# 
# ?ggplot
# qplot(log(F12),geom="histogram")
# 
# plot.myHistogram<-function(x){
#   qplot()
# }
# simple <- data.frame(x = rep(1:10, each = 2))
# base <- ggplot(simple, aes(x))
# base + stat_bin(binwidth = 1, drop = FALSE, right = FALSE, col = "black")
# 
# plot.myHistogram<-function(x){
# 
# }
# testDataframe<-data.frame(testhist$mids,testhist$count)
# ggplot(aes(x,y))+geom_histogram(data=testDataframe)
