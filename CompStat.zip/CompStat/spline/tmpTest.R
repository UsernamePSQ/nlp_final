myLoess <- function(x, y, maxspan=0.5, minspan = 0.01, step=0.01, ...){
  spanVar <- seq(from=minspan, to=maxspan, by=step)
  tmp     <- rep(NA, length(spanVar))
  for (i in seq(spanVar)){
    tmp[[i]] <- sum(abs(loess.smooth(x,y,spanVar[i], evaluation=length(x))$y-sPline$y))
  }
  bestSpan <- spanVar[tmp == min(tmp)]
  bestSpan
}


myLoess2 <- function(x,y,maxspan=0.5, minspan = 0.01, step=0.01, ...){
  spanVar <- seq(from=minspan, to=maxspan, by=step)
  tmp     <- list()
  for (i in seq(spanVar)){
    tmp[[i]] <- tryCatch(sum(abs(loess.smooth(x,y,spanVar[i], evaluation=length(x))$y-sPline$y)), 
                         warning = function(c) {msg <- conditionMessage(c)
                         invisible(structure(msg, class = "try-error"))})
  }
  spanVar <- as.vector(spanVar[!sapply(tmp, is.error)], mode = "numeric")
  resultSuccess <- as.vector(tmp[!sapply(tmp, is.error)], mode = "numeric")
  reultFails <-  as.vector(results[sapply(results, is.error)], mode = "character")
  bestSpan <- spanVar[resultSuccess == min(resultSuccess)]
  return(list(bestSpan = bestSpan, resultSuccess = resultSuccess, reultFails = reultFails))
}


is.error <- function(x) inherits(x, "try-error")

