Omegafunc<-function(x,method="default",nPoints=NULL){
  unix<-unique(x)
  if (method=="OR"){
    omegaTmp<-matrix(data=0,nrow=(length(unix)+2),ncol=(length(unix)+2))
    pointsTmp<-seq(min(unix),max(unix),length.out = nPoints)
    xdist<-.subset2(pointsTmp,2)-.subset2(pointsTmp,1)
    splineEvaluations<-splineDesign(x,pointsTmp,ord=4,derivs = rep(2,length(pointsTmp)),sparse = T)
    for(k in (1:length(pointsTmp))){
      omegaTmp<-omegaTmp+outer(splineEvaluations[k,],splineEvaluations[k,],"*")
    }
    omegaTmp<-omegaTmp*xdist
  } else  {
    omegaTmp<-bsplinepen(create.bspline.basis(range(c(min(unix),max(unix))), breaks = unix))
  }
  omegaTmp
}

mySpline0 <- function(x,y, n=100,method="default",nPoints=NULL,lower=0.0000001,upper=1,l){
  x <- sort(x)
  y <- y[order(x)]
  x <- c(rep(.subset2(x,1),3),x,rep(.subset2(x,length(x)),3))
  y <- c(rep(.subset2(y,1),3),y,rep(.subset2(y,length(y)),3))
  A <- splineDesign(knots = x, x = x, outer.ok = F, sparse = T)
  omega <- Omegafunc(x,method,nPoints)
  CVRSS <- rep(NA, n) 
  if(!missing(l)){lambda<-l}else{
    lambda <- seq(lower,upper,length.out = n)
    for (i in 1:n){
      S <- A%*%solve((t(A)%*%A+lambda[i]*omega))%*%t(A)
      shat <- S%*%y
      CVRSS[i] <- sum(  ( (y-shat)/(1-diag(S)) )^2 )
    }
    lambda<-lambda[CVRSS == min(CVRSS)]
  }
  shat <- A%*%solve((t(A)%*%A+lambda*omega))%*%t(A)%*%y
  if(!missing(l)){S <- A%*%solve((t(A)%*%A+l*omega))%*%t(A)
  CVRSS <- sum(  ( (y-shat)/(1-diag(S)) )^2 )}
  return(list(shat=shat,CVRSS=CVRSS))
}


mySpline <- function(x,y, n=100,method="default",nPoints=NULL,lower=0.0000001,upper=1,l){
  x <- sort(x)
  y <- y[order(x)]
  x <- c(rep(.subset2(x,1),3),x,rep(.subset2(x,length(x)),3))
  y <- c(rep(.subset2(y,1),3),y,rep(.subset2(y,length(y)),3))
  A <- splineDesign(knots = x, x = x, outer.ok = F, sparse = T)
  omega <- Omegafunc(x,method,nPoints)
  if(!missing(l)){lambda<-l}
  else{
    lambda <- seq(lower,upper,length.out = n)
    CVRSS <- sapply(lambda, function(l){
      S <- A%*%solve((t(A)%*%A+l*omega))%*%t(A)
      shat <- S%*%y
      return(sum(  ( (y-shat)/(1-diag(S)) )^2 )) }  )
    lambda<-lambda[CVRSS == min(CVRSS)]
  }
  shat <- A%*%solve((t(A)%*%A+lambda*omega))%*%t(A)%*%y
  if(!missing(l)){S <- A%*%solve((t(A)%*%A+l*omega))%*%t(A)
  CVRSS <- sum(  ( (y-shat)/(1-diag(S)) )^2 )}
  return(list(shat=shat,CVRSS=CVRSS))
}

mySpline1 <- function(x,y, n=100,method="default",nPoints=NULL,lower=0.0000001,upper=1,l){
  x <- sort(x)
  y <- y[order(x)]
  x <- c(rep(.subset2(x,1),3),x,rep(.subset2(x,length(x)),3))
  #y <- c(rep(.subset2(y,1),3),y,rep(.subset2(y,length(y)),3))
  A <- splineDesign(knots = x, x = x, outer.ok = F, sparse = T)[-c(1:3,((length(x)-2):length(x))),]
  omega <- Omegafunc(x,method,nPoints)
  if(!missing(l)){lambda<-l}
  else{
    lambda <- seq(lower,upper,length.out = n)
    CVRSS <- sapply(lambda, function(l){
      S <- A%*%solve((t(A)%*%A+l*omega))%*%t(A)
      shat <- S%*%y
      return(sum(  ( (y-shat)/(1-diag(S)) )^2 )) }  )
    lambda<-lambda[CVRSS == min(CVRSS)]
  }
  shat <- A%*%solve((t(A)%*%A+lambda*omega))%*%t(A)%*%y
  if(!missing(l)){S <- A%*%solve((t(A)%*%A+l*omega))%*%t(A)
  CVRSS <- sum(  ( (y-shat)/(1-diag(S)) )^2 )}
  return(list(shat=shat,CVRSS=CVRSS,A=A,omega=omega,lambda=lambda))
}

mySpline2<- function(x,y, n=100,method="default",nPoints=NULL,lower=0.0000001,upper=1,l){
  x <- sort(x)
  y <- y[order(x)]
  x2 <- c(rep(.subset2(x,1),3),x,rep(.subset2(x,length(x)),3))
  #y <- c(rep(.subset2(y,1),3),y,rep(.subset2(y,length(y)),3))
  A <- splineDesign(knots = x2, x = x, outer.ok = F, sparse = T)
  omega <- Omegafunc(x,method,nPoints)
  if(!missing(l)){lambda<-l}
  else{
    lambda <- seq(lower,upper,length.out = n)
    CVRSS <- sapply(lambda, function(l){
      S <- A%*%solve((t(A)%*%A+l*omega))%*%t(A)
      shat <- S%*%y
      return(sum(  ( (y-shat)/(1-diag(S)) )^2 )) }  )
    lambda<-lambda[CVRSS == min(CVRSS)]
  }
  shat <- A%*%solve((t(A)%*%A+lambda*omega))%*%t(A)%*%y
  if(!missing(l)){S <- A%*%solve((t(A)%*%A+l*omega))%*%t(A)
  CVRSS <- sum(  ( (y-shat)/(1-diag(S)) )^2 )}
  return(list(shat=shat,CVRSS=CVRSS,A=A,omega=omega,lambda=lambda))
}

mySpline3<- function(x,y, n=100,method="default",nPoints=NULL,lower=0.0000001,upper=1,l){
  x <- sort(x)
  y <- y[order(x)]
  x2 <- c(rep(.subset2(x,1),3),x,rep(.subset2(x,length(x)),3))
  x3<-(x-x[1])/(x[length(x)]-x[1])
  x4<-(x2-x2[1])/(x2[length(x2)]-x2[1])
  A <- splineDesign(knots = x4, x = x3, outer.ok = F, sparse = T)
  omega <- Omegafunc(x,method,nPoints)
  if(!missing(l)){lambda<-l}
  else{
    lambda <- seq(lower,upper,length.out = n)
    CVRSS <- sapply(lambda, function(l){
      S <- A%*%solve((t(A)%*%A+l*omega))%*%t(A)
      shat <- S%*%y
      return(sum(  ( (y-shat)/(1-diag(S)) )^2 )) }  )
    lambda<-lambda[CVRSS == min(CVRSS)]
  }
  shat <- A%*%solve((t(A)%*%A+lambda*omega))%*%t(A)%*%y
  if(!missing(l)){S <- A%*%solve((t(A)%*%A+l*omega))%*%t(A)
  CVRSS <- sum(  ( (y-shat)/(1-diag(S)) )^2 )}
  cvCrit=CVRSS[CVRSS == min(CVRSS)]/length(x)
  penCrit=sum((y-shat)^2)
  return(list(shat=shat,CVRSS=CVRSS,A=A,omega=omega,lambda=lambda,x4=x4,cvCrit=cvCrit,penCrit=penCrit))
}

PhiMatrix<-function(x){
  x2 <- c(rep(.subset2(x,1),3),x,rep(.subset2(x,length(x)),3))
  phi <- splineDesign(knots = x4, x = x3, outer.ok = F)
}

OmegaMatrix<-function(x){
    omegaTmp<-bsplinepen(create.bspline.basis(range(c(min(x),max(x))), breaks = x))
  omegaTmp
}

simpleResults<-function(y,phi,omega,lambda){
  S <- phi%*%solve((t(phi)%*%phi+lambda*omega))%*%t(phi)
  shat <- S%*%y
  CVRSS<-sum(  ( (y-shat)/(1-diag(S)) )^2 )
  cvCrit<-CvrssMatrix/length(y)
  return(list(shat=shat,lambda=lambda,CVRSS=min(CvrssMatrix),cvCrit=cvCrit))
}

CvrssMinimizer<-function(y,phi,omega,method="sapply",lower=0,upper=1,by=1e-2){
  if(method=="sapply"){
  tmplambda <- seq(lower,upper,by = by)
  tmp<-t(phi)%*%phi
  CvrssMatrix <- sapply(tmplambda, function(l){
    S <- phi%*%solve((tmp+l*omega))%*%t(phi)
    shat <- S%*%y
    return(sum(  ( (y-shat)/(1-diag(S)) )^2 )) }  )
  tmplambda<-tmplambda[CvrssMatrix == min(CvrssMatrix)]
  shat<-phi%*%solve((tmp+lambda*omega))%*%t(phi)%*%y }
  else {stop("unsupported method argument")}
  return(list(shat=shat,lambda=lambda,CVRSS=min(CvrssMatrix),cvCrit=min(CvrssMatrix)/length(y)))
}



mySpline4<-function(x,y,method="sapply",lower=0,upper=1,by=1e-2,lambda,scaling=F)
  if(scaling){x<-(x-x[1])/(x[length(x)]-x[1])}
  phi<-PhiMatrix(x)
  omega<-OmegaMatrix(x)
  if(ismissing(lambda)){
    resultList<-CvrssMinimizer(y,phi,omega,method=method,lower,upper,by)
  } else {
    resultList<-simpleResults(y,phi,omega,lambda)
  }
  return(c(x=x,resultList))