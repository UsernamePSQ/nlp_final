setwd("CSdatasets")
library('splines')
library('Matrix')
library('fda')
library('microbenchmark')
library('ggplot2')
library('profvis')
data <- read.table('easysmooth.dat', header = T)
x <- data$X
y <- data$Y


Omegafunc<-function(x,method="default",nPoints=NULL){
  unix<-unique(x)
  if (method=="OR"){
    omegaTmp<-matrix(data=0,nrow=(length(unix)+2),ncol=(length(unix)+2))
    pointsTmp<-seq(min(unix),max(unix),length.out = nPoints)
    xdist<-.subset2(pointsTmp,2)-.subset2(pointsTmp,1)
    splineEvaluations<-splineDesign(x,pointsTmp,ord=4,derivs = rep(2,length(pointsTmp)),sparse = T)
    for(k in (1:length(pointsTmp))){
      omegaTmp<-omegaTmp+outer(splineEvaluations[k,],splineEvaluations[k,],"*")
    }
    omegaTmp<-omegaTmp*xdist
  } else  {
    omegaTmp<-bsplinepen(create.bspline.basis(range(c(min(unix),max(unix))), breaks = unix))
  }
  omegaTmp
}

mySpline0 <- function(x,y, n=100,method="default",nPoints=NULL,lower=0.0000001,upper=1,l){
  x <- sort(x)
  y <- y[order(x)]
  x <- c(rep(.subset2(x,1),3),x,rep(.subset2(x,length(x)),3))
  y <- c(rep(.subset2(y,1),3),y,rep(.subset2(y,length(y)),3))
  A <- splineDesign(knots = x, x = x, outer.ok = F, sparse = T)
  omega <- Omegafunc(x,method,nPoints)
  CVRSS <- rep(NA, n) 
  if(!missing(l)){lambda<-l}else{
    lambda <- seq(lower,upper,length.out = n)
    for (i in 1:n){
      S <- A%*%solve((t(A)%*%A+lambda[i]*omega))%*%t(A)
      shat <- S%*%y
      CVRSS[i] <- sum(  ( (y-shat)/(1-diag(S)) )^2 )
    }
    lambda<-lambda[CVRSS == min(CVRSS)]
  }
  shat <- A%*%solve((t(A)%*%A+lambda*omega))%*%t(A)%*%y
  if(!missing(l)){S <- A%*%solve((t(A)%*%A+l*omega))%*%t(A)
  CVRSS <- sum(  ( (y-shat)/(1-diag(S)) )^2 )}
  return(list(shat=shat,CVRSS=CVRSS))
}
shat0<-mySpline0(x,y)$shat

mySpline <- function(x,y, n=100,method="default",nPoints=NULL,lower=0.0000001,upper=1,l){
  x <- sort(x)
  y <- y[order(x)]
  x <- c(rep(.subset2(x,1),3),x,rep(.subset2(x,length(x)),3))
  y <- c(rep(.subset2(y,1),3),y,rep(.subset2(y,length(y)),3))
  A <- splineDesign(knots = x, x = x, outer.ok = F, sparse = T)
  omega <- Omegafunc(x,method,nPoints)
  if(!missing(l)){lambda<-l}
  else{
    lambda <- seq(lower,upper,length.out = n)
    CVRSS <- sapply(lambda, function(l){
      S <- A%*%solve((t(A)%*%A+l*omega))%*%t(A)
      shat <- S%*%y
      return(sum(  ( (y-shat)/(1-diag(S)) )^2 )) }  )
    lambda<-lambda[CVRSS == min(CVRSS)]
  }
  shat <- A%*%solve((t(A)%*%A+lambda*omega))%*%t(A)%*%y
  if(!missing(l)){S <- A%*%solve((t(A)%*%A+l*omega))%*%t(A)
  CVRSS <- sum(  ( (y-shat)/(1-diag(S)) )^2 )}
  return(list(shat=shat,CVRSS=CVRSS))
}
shat<-mySpline(x,y)$shat

#First test
plot(x,y)
lines(x,shat[-c(1:3,204:206)], col = 'blue')
sPline <- smooth.spline(x,y, all.knots = T)
lines(sPline,col="black")

#Basic functionallity:
testSet1<-cbind(1:100,1:100)
testSet2<-cbind(seq((-4),2,length.out = 40),seq(-4,4,length.out = 40))
testSet3<-cbind(c(seq(0,4,length.out = 20),seq(4.1,8,length.out = 60)),c(rep(1,20),seq(4,12,length.out = 60)))
testSet4<-cbind(seq(0,10,length.out = 50),(sapply(seq(0,10,length.out = 50),function(x) 40-8*x+1.5*x^2-0.1*x^3)))
testSet5<-cbind(seq(0,10,length.out = 50),(sapply(seq(0,10,length.out = 50),function(x)40-8*x+1.5*x^2-0.1*x^3))+rnorm(50,mean=0,sd=0.4))
testSet6<-cbind(seq(0,10,length.out = 50),(sapply(seq(0,10,length.out = 50),function(x)40-8*x+1.5*x^2-0.1*x^3))+rnorm(50,mean=0,sd=1))
testSet7<-cbind(seq(0,10,length.out = 50),(sapply(seq(0,10,length.out = 50),function(x)40-8*x+1.5*x^2-0.1*x^3))+rnorm(50,mean=0,sd=2))
testList<-list(testSet1,
               testSet2,
               testSet3,
               testSet4,
               testSet5,
               testSet6,
               testSet7
)
par(mfrow=c(3,3))
for(i in (1:length(testList))) {
  plot(testList[[i]],xlab="",ylab="")
  lines(testList[[i]][,1], mySpline(testList[[i]][,1],testList[[i]][,2],n=100,method="OR",nPoints=500)$shat[c(4:(length(testList[[i]][,1])+3))],col="red")
  lines(testList[[i]][,1], mySpline(testList[[i]][,1],testList[[i]][,2],n=100)$shat[c(4:(length(testList[[i]][,1])+3))],col="blue")
  lines(smooth.spline(testList[[i]][,1],testList[[i]][,2],all.knots = T),col="black")}

par(mfrow=c(2,1))
plot(testSet3,xlab="",ylab="")
lines(testSet3[,1],mySpline(testSet3[,1],testSet3[,2])$shat[c(4:(length(testSet3[,1])+3))],col="blue")
lines(smooth.spline(testSet3[,1],testSet3[,2]),col="black")
lines(testSet3[,1],mySpline(testSet3[,1],testSet3[,2],l=0.0000000001)$shat[c(4:(length(testSet3[,1])+3))],col="red")
lines(testSet3[,1],mySpline(testSet3[,1],testSet3[,2],l=100000)$shat[c(4:(length(testSet3[,1])+3))],col="green")
plot(testSet7,xlab="",ylab="")
lines(testSet4,col="yellow")
lines(testSet7[,1],mySpline(testSet7[,1],testSet7[,2])$shat[c(4:(length(testSet7[,1])+3))],col="blue")
lines(smooth.spline(testSet7[,1],testSet7[,2]),col="black")
lines(testSet7[,1],mySpline(testSet7[,1],testSet7[,2],l=0.0000000001)$shat[c(4:(length(testSet7[,1])+3))],col="red")
lines(testSet7[,1],mySpline(testSet7[,1],testSet7[,2],l=100000)$shat[c(4:(length(testSet7[,1])+3))],col="green")
par(mfrow=c(1,1))

#Choosing integration procedure
base<-mySpline(x,y)$shat
testOfIntegrationMethod<-rep(NA,11)
for (i in 1:10){
  testOfIntegrationMethod[i]<-sum(abs(base-mySpline(x,y,n=100,method="OR",nPoints = i*1000)$shat))
}
testOfIntegrationMethod[11]<-sum(abs(base-mySpline(x,y,n=100,method="OR",nPoints = 30000)$shat))
smalltestOfIntegrationMethod<-rep(NA,10)
for (i in 1:10){
  smalltestOfIntegrationMethod[i]<-sum(abs(base-mySpline(x,y,n=100,method="OR",nPoints = i*100)$shat))
}
testOfIntegrationMethod
smalltestOfIntegrationMethod

profile1<-profvis(mySpline(x,y,method="OR",nPoints=500))
profile2<-profvis(mySpline(x,y,method="OR",nPoints=10000))
profile3<-profvis(mySpline(x,y))

#Choosing numbers of lambdas to try
plot(x,y)
col<-rainbow(10)
for (i in 1:10){
  lines(x,mySpline(x,y, n=10*i,upper=1)$shat[-c(1:3,204:206)], col = col[i])
}
rm(col)

qplot(seq(0.0000001,10,length.out = 1000), mySpline(x,y,n=1000,upper=10)$CVRSS, xlab = "lambda", ylab = "CVRSS")+geom_line()


### Microbenchmark ###
#n and sapply vs loop
tmp <- microbenchmark(mySpline0(x,y,10),
                      mySpline0(x,y,20),
                      mySpline0(x,y,30),
                      mySpline0(x,y,40),
                      mySpline0(x,y,50),
                      mySpline0(x,y,60),
                      mySpline0(x,y,70),
                      mySpline0(x,y,80),
                      mySpline0(x,y,90),
                      mySpline0(x,y),
                      mySpline(x,y,10),
                      mySpline(x,y,20),
                      mySpline(x,y,30),
                      mySpline(x,y,40),
                      mySpline(x,y,50),
                      mySpline(x,y,60),
                      mySpline(x,y,70),
                      mySpline(x,y,80),
                      mySpline(x,y,90),
                      mySpline(x,y),
                      smooth.spline(x,y,all.knots = T), times = 20)
summary(tmp)
autoplot(tmp)



### Christian ###
########### Loess smoothing by different spans

#### NOTE - Span differs from function calls, see for instance function "loess" 
#### here is shows that 'high' values such as 0.75 (default) returns VERY smooth 

plot(x,y)
lines(sPline,       col="blue"  )  #smooth.spline
lines(x,shat[4:203], col="yellow")  #mySpline

lines(loess.smooth(x,y))            #default span
lines(loess.smooth(x,y, span=0.5, evaluation = length(x)))
lines(loess.smooth(x,y, span=0.25))
lines(loess.smooth(x,y, span=0.1))


####        Choice of span?
########### Optimal span parameter for loess.smooth splines could be chosen by...  

myLoess <- function(x,y,maxspan=0.5, minspan = 0.01, step=0.01, ...){
  maxspan <- min(0.75, maxspan)
  minspan <- max(1e-10, minspan) 
  spanVar <- seq(from=minspan, to=maxspan, by=step)
  tmp     <- rep(0, length(spanVar))
  for (i in seq(spanVar)){
    tmp[i] <- sum(abs(loess.smooth(x,y,spanVar[i], evaluation=length(x))$y-sPline$y))
  }
  bestSpan <- spanVar[tmp == min(tmp)]
  bestSpan
}

############ Generating loess.smooth
SpanValue1 <- myLoess(x, y)
#Possible warnings: degree of freedom and memory (supposedly results in a more rough estimate)
SpanValue2 <- myLoess2(x, y)$bestSpan
bestLoess <- loess.smooth(x,y,span = SpanValue2, evaluation =length(x))
shat      <- mySpline(x,y)$shat

### Plot of smoothings
plot(x,y, main = "Smoothing of data", sub = "Blue = sPline, red = Loess, yellow = mySpline")
lines(sPline,         col="blue"  )
lines(bestLoess,      col="red"   )
lines(x, shat[4:203], col="yellow")

# absolute difference from smooth.spline
c(sum(abs(shat[4:203]-sPline$y)), sum(abs(bestLoess$y-sPline$y)) )

########### Difference from smooth.spline

plot(x, shat[4:203] - sPline$y, col="blue", type="l", ylim=range(bestLoess$y - sPline$y),
     main = "Difference from smooth.spline", sub="Green = Loess,   Blue = mySpline", ylab="", xlab="")
lines(x, bestLoess$y - sPline$y, col="green")
abline(0,0, type="1")
#### Chr end ####

#Scaling
  longdata <- cbind(seq(0,10,length.out = 2^12),(sapply(seq(0,10,length.out = 2^12),function(x)40-8*x+1.5*x^2-0.1*x^3))+rnorm(2^12,mean=0,sd=2))

tmp0 <- microbenchmark(mySpline(longdata[1:(2^5),1],longdata[1:(2^5),2],10),
                       mySpline(longdata[1:(2^6),1],longdata[1:(2^6),2],10),
                       mySpline(longdata[1:(2^7),1],longdata[1:(2^7),2],10),
                       mySpline(longdata[1:(2^8),1],longdata[1:(2^8),2],10),
                       mySpline(longdata[1:(2^9),1],longdata[1:(2^9),2],10),
                       mySpline(longdata[1:(2^10),1],longdata[1:(2^10),2],10),
                       smooth.spline(longdata[1:(2^5),1],longdata[1:(2^5),2], all.knots = TRUE),
                       smooth.spline(longdata[1:(2^6),1],longdata[1:(2^6),2], all.knots = TRUE),
                       smooth.spline(longdata[1:(2^7),1],longdata[1:(2^7),2], all.knots = TRUE),
                       smooth.spline(longdata[1:(2^8),1],longdata[1:(2^8),2], all.knots = TRUE),
                       smooth.spline(longdata[1:(2^9),1],longdata[1:(2^9),2], all.knots = TRUE),
                       smooth.spline(longdata[1:(2^10),1],longdata[1:(2^10),2], all.knots = TRUE),
                       times = 20)
autoplot(tmp0)

#What to work on - thoughts to consider
plot(x,y)
lines(x,shat[-c(1:3,204:206)], col = 'blue')
sPline <- smooth.spline(x,y, all.knots = T)
lines(sPline,col="black")
plot(sPline$y-shat[-c(1:3,204:206)],type='l', ylab = "Difference")
