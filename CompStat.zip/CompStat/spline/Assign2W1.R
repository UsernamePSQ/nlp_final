library(splines)
library(Matrix)
library(fda)
#wd<-setwd("CSdatasets")
dataInit <- read.table("easysmooth.dat",header=T)
plot(dataInit)
rSplines<-smooth.spline(x=dataInit$X,y=dataInit$Y,all.knots = TRUE, cv=T)
lines(rSplines)

data1<-rbind(dataInit[1,],dataInit[1,],dataInit[1,],dataInit,dataInit[200,],dataInit[200,],dataInit[200,])
plot(data1)
rSplines<-smooth.spline(x=data1$X,y=data1$Y,all.knots = T, cv=T)
lines(rSplines)



#base1<-mySpline1(dataInit$X,dataInit$Y)
base2<-mySpline2(dataInit$X,dataInit$Y)
base3<-mySpline3(dataInit$X,dataInit$Y)
plot(dataInit$X,dataInit$Y)
lines(dataInit$X,base2$shat, col = 'blue')
sPline <- smooth.spline(dataInit$X,dataInit$Y, all.knots =T,cv=T)
lines(sPline,col="black")

plot(dataInit$X,base2$shat-sPline$y,type="l") 


betterThanBase<-mySpline2(dataInit$X,dataInit$Y,n=10000,lower=0.000000001,upper=0.1)
plot(dataInit$X,dataInit$Y)
lines(dataInit$X,betterThanBase$shat, col = 'blue')
sPline <- smooth.spline(dataInit$X,dataInit$Y, all.knots =T,cv=T)
lines(sPline,col="black")


plot(dataInit$X,betterThanBase$shat-sPline$y,type="l")
######################################################################
###### cv.crit and pen.crit are close even though lambda is far ######
######################################################################

#Only cv.crit adds info that plot of differences of shat and sPline$y dos not.
#Given same CVRSS

#cv.crit is almost CVRSS - only a mean instead of a sum
#pen.crit is sum of (y-shat)^2
# > base3$cvCrit;sPline$cv.crit
# [1] 2.162445
# [1] 2.162354
# > base3$penCrit;sPline$pen.crit
# [1] 380.9834
# [1] 380.2965

#Closer examination:
# betterThanBase<-mySpline3(dataInit$X,dataInit$Y,n=10000,lower=0.000000001,upper=0.1)
# > betterThanBase$cvCrit;sPline$cv.crit;
# [1] 2.162354
# [1] 2.162354


##Integration test: how well does it minimize CVRSS? Takes long time
#CVRSSTest1<-mySpline1(dataInit$X,dataInit$Y,n=10000,lower=0.000000000000001,upper=1)
#CVRSSTest2<-mySpline1(dataInit$X,dataInit$Y,n=10000, method="OR",nPoints=50000,lower=0.000000000000001,upper=1)
# > min(CVRSSTest1$CVRSS)
# [1] 432.4708
# > min(CVRSSTest2$CVRSS)
# [1] 432.4708


base<-mySpline(dataInit$X,dataInit$Y)$shat
testOfIntegrationMethod<-rep(NA,11)
for (i in 1:10){
  testOfIntegrationMethod[i]<-sum(abs(base-mySpline(dataInit$X,dataInit$Y,n=100,method="OR",nPoints = i*1000)$shat))
}
testOfIntegrationMethod[11]<-sum(abs(base-mySpline(dataInit$X,dataInit$Y,n=100,method="OR",nPoints = 30000)$shat))
smalltestOfIntegrationMethod<-rep(NA,10)
for (i in 1:10){
  testOfIntegrationMethod[i]<-sum(abs(base-mySpline(dataInit$X,dataInit$Y,n=100,method="OR",nPoints = i*100)$shat))
}
testOfIntegrationMethod
smalltestOfIntegrationMethod


profile1<-profvis(mySpline(dataInit$X,dataInit$Y,method="OR",nPoints=500))
profile2<-profvis(mySpline(dataInit$X,dataInit$Y,method="OR",nPoints=10000))
profile3<-profvis(mySpline(dataInit$X,dataInit$Y))







mySmoothSpline<-function(x,y,lambda=0.5,sparse = FALSE){
  phi<-splineDesign(x,x,outer.ok = F,sparse = sparse)
  omega<-bsplinepen(create.bspline.basis(range(c(min(x),max(x))), breaks = unique(x)))
  tmpVar<-solve(((t(phi)%*%phi)+lambda*omega))%*%t(phi)
  sMatrix<-phi%*%tmpVar
  betaHat<-tmpVar%*%y
  sHat<-phi%*%betaHat
  return(list(sMatrix=sMatrix,sHat=sHat))
}

mSS<-mySmoothSpline(data1$X,data1$Y,lambda = 0.05)
CVRSS<-sum(((data1$Y-mSS$sHat)/(1-diag(mSS$sMatrix)))^2)


phi<-splineDesign(data1$X,data1$X,outer.ok = F,sparse = T)
omega<-bsplinepen(create.bspline.basis(range(c(min(dataInit$X),max(dataInit$X))), breaks = dataInit$X))
lambda<-0.066
tmpVar<-solve(((t(phi)%*%phi)+lambda*omega))%*%t(phi)
sMatrix<-phi%*%tmpVar
betaHat<-tmpVar%*%data1$Y
sHat<-phi%*%betaHat
lines(x=data1$X,y=sHat)





#Test datasets:
testSet1<-cbind(1:100,1:100)
testSet2<-cbind(seq((-4),2,length.out = 40),seq(-4,4,length.out = 40))
testSet3<-cbind(c(seq(0,4,length.out = 20),seq(4.1,8,length.out = 60)),c(rep(1,20),seq(4,12,length.out = 60)))
testSet4<-cbind(seq(0,10,length.out = 50),(lapply(seq(0,10,length.out = 50),function(x) 40-8*x+1.5*x^2-0.1*x^3)))
testSet5<-cbind(seq(0,10,length.out = 50),(sapply(seq(0,10,length.out = 50),function(x)40-8*x+1.5*x^2-0.1*x^3))+rnorm(50,mean=0,sd=0.4))
testSet6<-cbind(seq(0,10,length.out = 50),(sapply(seq(0,10,length.out = 50),function(x)40-8*x+1.5*x^2-0.1*x^3))+rnorm(50,mean=0,sd=1))
testSet7<-cbind(seq(0,10,length.out = 50),(sapply(seq(0,10,length.out = 50),function(x)40-8*x+1.5*x^2-0.1*x^3))+rnorm(50,mean=0,sd=2))
testList<-list(testSet1,
               testSet2,
               testSet3,
               testSet4,
               testSet5,
               testSet6,
               testSet7
)
par(mfrow=c(3,3))
for(i in (1:length(testList))) {plot(testList[[i]],xlab="",ylab="")}
par(mfrow=c(1,1))

#Scaling test
par(mfrow=c(3,3))
scalingTestList<-list()
# for(i in (5:12)){scalingTestList[i]<-}
par(mfrow=c(1,1))
